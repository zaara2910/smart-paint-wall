import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { errorText } from '../core/auth.interceptor';

@Component({
  selector: 'app-help',
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="page narrow">
      <h1>How to use the visualizer</h1>
      <div class="card guide">
        <h3>1. Upload your room</h3>
        <p>Go to <b>New room</b>, choose a JPG or PNG photo that you own, and press upload. Photos taken in daylight with the walls fully visible work best.</p>
        <h3>2. Select the walls</h3>
        <p><b>Polygon tool:</b> click each corner of a wall. Double-click, press Enter, or click the first point to finish. <b>Brush tool:</b> drag over the area you want to paint, which suits curved or irregular shapes. <b>Select tool:</b> click a wall, then drag its corner points to adjust it. Right-click a corner to remove it.</p>
        <h3>3. Apply paint</h3>
        <p>Pick a colour from the palette. Choose <b>Dual-tone</b> to paint the lower and upper parts of a wall in two colours, or <b>Pattern</b> for stripes, florals and more. Use opacity, brightness and finish to fine-tune how real it looks.</p>
        <h3>4. Compare and try alternatives</h3>
        <p>Use <b>Before</b>, <b>After</b> and <b>Split</b> to compare. Each room can hold several <b>design trials</b>, so you can test different looks side by side.</p>
        <h3>5. Save or download</h3>
        <p>Press <b>Save</b> to keep your design in Saved designs. Use <b>Download</b> for a PNG of the painted room or a before and after image.</p>
        <p class="muted"><b>Keyboard:</b> Enter finishes a polygon · Esc cancels · Ctrl+Z undo · Ctrl+Y redo · Delete removes the selected wall.</p>
        <p class="alert info">Results are an approximation. Final colours can differ because of room lighting, screen calibration and wall texture, so test a small patch before you buy paint.</p>
      </div>

      <h2 class="gap">Tell us how it went</h2>
      <form class="card" (ngSubmit)="send()">
        @if (msg) { <div class="alert" [class.ok]="sent" [class.error]="!sent" role="status">{{ msg }}</div> }
        <label class="field">Your rating
          <select name="rating" [(ngModel)]="rating"><option [ngValue]="5">5 - Excellent</option><option [ngValue]="4">4 - Good</option><option [ngValue]="3">3 - Okay</option><option [ngValue]="2">2 - Poor</option><option [ngValue]="1">1 - Very poor</option></select>
        </label>
        <label class="field">Comments (optional)
          <textarea name="comment" rows="3" maxlength="500" [(ngModel)]="comment"></textarea>
        </label>
        <button class="btn primary">Send feedback</button>
      </form>
    </div>
  `,
  styles: [`.narrow { max-width: 780px; } .guide h3 { margin-top: 14px; } .gap { margin-top: 28px; }`],
})
export class HelpComponent {
  private http = inject(HttpClient);
  rating = 5; comment = ''; msg = ''; sent = false;
  send() {
    this.http.post('/api/feedback', { rating: this.rating, comment: this.comment }).subscribe({
      next: () => { this.sent = true; this.msg = 'Thank you for your feedback.'; this.comment = ''; },
      error: (e) => { this.sent = false; this.msg = errorText(e); },
    });
  }
}
