import { Component, inject, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Project } from '../core/models';

@Component({
  selector: 'app-saved',
  standalone: true,
  imports: [RouterLink, DatePipe],
  template: `
    <div class="page">
      <div class="row spread">
        <h1>Saved designs</h1>
        <a class="btn primary" routerLink="/upload">New room</a>
      </div>
      <div class="row filters">
        <button class="btn small" [class.active]="!onlySaved" (click)="onlySaved = false">All rooms</button>
        <button class="btn small" [class.active]="onlySaved" (click)="onlySaved = true">Saved only</button>
      </div>
      @if (!loaded) { <p class="muted">Loading…</p> }
      @else if (!shown.length) {
        <div class="card empty"><h3>Nothing here yet</h3><p>Paint a room and press Save to see it here.</p></div>
      } @else {
        <div class="grid cols-4">
          @for (p of shown; track p._id) {
            <div class="card">
              <img class="thumb" [src]="p.thumbnail || p.originalImage.url" [alt]="p.title">
              <h3>{{ p.title }} @if (p.saved) { <span class="tag ok">Saved</span> }</h3>
              <p class="muted">{{ p.trials.length }} {{ p.trials.length === 1 ? 'trial' : 'trials' }} · {{ p.updatedAt | date: 'medium' }}</p>
              <div class="row">
                <a class="btn small primary" [routerLink]="['/editor', p._id]">Open</a>
                <button class="btn small danger" (click)="remove(p)">Delete</button>
              </div>
            </div>
          }
        </div>
      }
    </div>
  `,
  styles: [`.filters { margin: 12px 0 18px; }`],
})
export class SavedComponent implements OnInit {
  private http = inject(HttpClient);
  projects: Project[] = [];
  loaded = false;
  onlySaved = false;
  get shown() { return this.onlySaved ? this.projects.filter((p) => p.saved) : this.projects; }

  ngOnInit() {
    this.http.get<Project[]>('/api/projects').subscribe({ next: (p) => { this.projects = p; this.loaded = true; }, error: () => (this.loaded = true) });
  }

  remove(p: Project) {
    if (!confirm(`Delete "${p.title}" and its photo? This cannot be undone.`)) return;
    this.http.delete(`/api/projects/${p._id}`).subscribe(() => (this.projects = this.projects.filter((x) => x._id !== p._id)));
  }
}
