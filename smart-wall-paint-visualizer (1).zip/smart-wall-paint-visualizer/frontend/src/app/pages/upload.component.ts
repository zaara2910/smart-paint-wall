import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { errorText } from '../core/auth.interceptor';
import { Project, PublicSettings } from '../core/models';

@Component({
  selector: 'app-upload',
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="page narrow">
      <h1>Upload a room photo</h1>
      <p class="muted">Use a clear, well-lit photo with the walls fully visible. JPG or PNG, up to {{ maxMB }} MB.</p>

      @if (error) { <div class="alert error" role="alert">{{ error }}</div> }

      <div class="card">
        <label class="drop" [class.over]="over" (dragover)="$event.preventDefault(); over = true" (dragleave)="over = false" (drop)="onDrop($event)">
          @if (preview) {
            <img [src]="preview" alt="Selected room photo preview">
          } @else {
            <span><b>Drop your photo here</b><br>or click to browse</span>
          }
          <input type="file" accept="image/jpeg,image/png" (change)="onPick($event)" hidden>
        </label>

        <label class="field">Room name
          <input type="text" [(ngModel)]="title" name="title" maxlength="80" placeholder="e.g. Living room">
        </label>

        <label class="check">
          <input type="checkbox" [(ngModel)]="owns" name="owns">
          <span>This is my own photo, or I have permission to use it, and it does not show other people's private information.</span>
        </label>

        <div class="row">
          <button class="btn primary" (click)="upload()" [disabled]="!file || !owns || busy">{{ busy ? 'Uploading…' : 'Upload and start painting' }}</button>
          <span class="muted">{{ settings?.disclaimer }}</span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .narrow { max-width: 760px; }
    .drop { display: grid; place-items: center; min-height: 260px; border: 2px dashed #b3bbd0; border-radius: 12px; cursor: pointer; text-align: center; color: var(--muted); margin-bottom: 18px; background: #f7f8fb; overflow: hidden; }
    .drop.over { border-color: var(--primary); background: #eef0fd; }
    .drop img { max-width: 100%; max-height: 380px; display: block; }
    .check { display: flex; gap: 10px; align-items: flex-start; margin-bottom: 18px; }
    .check input { margin-top: 4px; }
  `],
})
export class UploadComponent implements OnInit {
  private http = inject(HttpClient);
  private router = inject(Router);
  file?: File;
  preview = '';
  title = '';
  owns = false;
  busy = false;
  over = false;
  error = '';
  maxMB = 8;
  settings?: PublicSettings;
  private dims = { width: 0, height: 0 };

  ngOnInit() {
    this.http.get<PublicSettings>('/api/settings/public').subscribe((s) => { this.settings = s; this.maxMB = s.maxUploadMB; });
  }

  onPick(e: Event) {
    const f = (e.target as HTMLInputElement).files?.[0];
    if (f) this.choose(f);
  }

  onDrop(e: DragEvent) {
    e.preventDefault();
    this.over = false;
    const f = e.dataTransfer?.files?.[0];
    if (f) this.choose(f);
  }

  private choose(f: File) {
    this.error = '';
    if (!['image/jpeg', 'image/png'].includes(f.type)) { this.error = 'Only JPG and PNG images are supported.'; return; }
    if (f.size > this.maxMB * 1024 * 1024) { this.error = `This image is larger than ${this.maxMB} MB. Choose a smaller one.`; return; }
    this.file = f;
    if (!this.title) this.title = f.name.replace(/\.[^.]+$/, '').slice(0, 80);
    const url = URL.createObjectURL(f);
    const img = new Image();
    img.onload = () => { this.dims = { width: img.naturalWidth, height: img.naturalHeight }; };
    img.src = url;
    this.preview = url;
  }

  upload() {
    if (!this.file) return;
    const fd = new FormData();
    fd.append('title', this.title);
    fd.append('width', String(this.dims.width));
    fd.append('height', String(this.dims.height));
    fd.append('image', this.file);
    this.busy = true;
    this.http.post<Project>('/api/projects', fd).subscribe({
      next: (p) => this.router.navigate(['/editor', p._id]),
      error: (e) => { this.error = errorText(e, 'Upload failed.'); this.busy = false; },
    });
  }
}
