import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { DatePipe, DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { errorText } from '../../core/auth.interceptor';
import { Color, Pattern, Project, User } from '../../core/models';

type Tab = 'dashboard' | 'colors' | 'patterns' | 'users' | 'designs' | 'activity' | 'settings';

interface Stats {
  users: number; uploads: number; savedDesigns: number; downloads: number;
  avgSessionSeconds: number; avgRating: number; feedbackCount: number;
  uploadsPerDay: { date: string; uploads: number }[];
  topColors: { color: string; uses: number }[];
}
interface Feedback { _id: string; rating: number; comment: string; createdAt: string; user?: { name: string } }
interface ActivityRow { _id: string; action: string; createdAt: string; user?: { name: string; email: string } }
interface Settings { siteName: string; maxUploadMB: number; allowRegistration: boolean; maxTrialsPerProject: number; disclaimer: string }

const FINISHES = ['matte', 'satin', 'glossy', 'eggshell'];

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [FormsModule, DatePipe, DecimalPipe],
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.scss',
})
export class AdminComponent implements OnInit, OnDestroy {
  private http = inject(HttpClient);
  tabs: { id: Tab; label: string }[] = [
    { id: 'dashboard', label: 'Analytics' }, { id: 'colors', label: 'Colours' }, { id: 'patterns', label: 'Designs & patterns' },
    { id: 'users', label: 'Users' }, { id: 'designs', label: 'Saved designs' }, { id: 'activity', label: 'Activity' }, { id: 'settings', label: 'Settings' },
  ];
  tab: Tab = 'dashboard';
  msg = ''; msgOk = true;
  finishes = FINISHES;

  stats?: Stats;
  feedback: Feedback[] = [];
  colors: Color[] = [];
  patterns: Pattern[] = [];
  users: User[] = [];
  projects: Project[] = [];
  activity: ActivityRow[] = [];
  settings?: Settings;
  private timer?: ReturnType<typeof setInterval>;

  // forms
  colorForm = this.blankColor();
  editingColor: string | null = null;
  patternForm = { name: '', description: '', category: 'General', scale: 1 };
  patternFile?: File;

  ngOnInit() {
    this.load();
    // "real-time" KPIs: refresh the analytics tab every 10 seconds
    this.timer = setInterval(() => { if (this.tab === 'dashboard') this.loadStats(); }, 10000);
  }
  ngOnDestroy() { clearInterval(this.timer); }

  open(t: Tab) { this.tab = t; this.msg = ''; this.load(); }

  load() {
    switch (this.tab) {
      case 'dashboard': this.loadStats(); this.http.get<Feedback[]>('/api/admin/feedback').subscribe((f) => (this.feedback = f)); break;
      case 'colors': this.http.get<Color[]>('/api/admin/colors').subscribe((c) => (this.colors = c)); break;
      case 'patterns': this.http.get<Pattern[]>('/api/admin/patterns').subscribe((p) => (this.patterns = p)); break;
      case 'users': this.http.get<User[]>('/api/admin/users').subscribe((u) => (this.users = u)); break;
      case 'designs': this.http.get<Project[]>('/api/admin/projects').subscribe((p) => (this.projects = p)); break;
      case 'activity': this.http.get<ActivityRow[]>('/api/admin/activity').subscribe((a) => (this.activity = a)); break;
      case 'settings': this.http.get<Settings>('/api/admin/settings').subscribe((s) => (this.settings = s)); break;
    }
  }
  loadStats() { this.http.get<Stats>('/api/admin/stats').subscribe((s) => (this.stats = s)); }

  private say(text: string, ok = true) { this.msg = text; this.msgOk = ok; }
  private fail = (e: unknown) => this.say(errorText(e), false);

  get maxDay() { return Math.max(1, ...(this.stats?.uploadsPerDay.map((d) => d.uploads) || [1])); }
  get maxUse() { return Math.max(1, ...(this.stats?.topColors.map((c) => c.uses) || [1])); }
  minutes(sec: number) { return sec >= 60 ? `${Math.floor(sec / 60)}m ${sec % 60}s` : `${sec}s`; }
  val(e: Event) { return (e.target as HTMLInputElement).value; }

  /* colours */
  private blankColor() { return { name: '', code: '', hex: '#7fb7d6', brand: '', finishes: ['matte', 'satin', 'glossy'] as string[], categories: '', active: true }; }
  editColor(c: Color) {
    this.editingColor = c._id;
    this.colorForm = { name: c.name, code: c.code || '', hex: c.hex, brand: c.brand, finishes: [...c.finishes], categories: c.categories.join(', '), active: c.active };
    scrollTo({ top: 0, behavior: 'smooth' });
  }
  cancelColor() { this.editingColor = null; this.colorForm = this.blankColor(); }
  toggleFinish(f: string) {
    const i = this.colorForm.finishes.indexOf(f);
    if (i >= 0) this.colorForm.finishes.splice(i, 1); else this.colorForm.finishes.push(f);
  }
  saveColor() {
    const req = this.editingColor ? this.http.put(`/api/admin/colors/${this.editingColor}`, this.colorForm) : this.http.post('/api/admin/colors', this.colorForm);
    req.subscribe({ next: () => { this.say(this.editingColor ? 'Colour updated.' : 'Colour added.'); this.cancelColor(); this.load(); }, error: this.fail });
  }
  toggleColor(c: Color) { this.http.put(`/api/admin/colors/${c._id}`, { active: !c.active }).subscribe({ next: () => this.load(), error: this.fail }); }
  deleteColor(c: Color) {
    if (confirm(`Delete colour "${c.name}"? Existing designs keep their painted colour.`)) this.http.delete(`/api/admin/colors/${c._id}`).subscribe({ next: () => { this.say('Colour deleted.'); this.load(); }, error: this.fail });
  }

  /* patterns */
  pickFile(e: Event) { this.patternFile = (e.target as HTMLInputElement).files?.[0]; }
  addPattern() {
    if (!this.patternFile) { this.say('Choose a JPG or PNG texture image.', false); return; }
    const fd = new FormData();
    Object.entries(this.patternForm).forEach(([k, v]) => fd.append(k, String(v)));
    fd.append('image', this.patternFile);
    this.http.post('/api/admin/patterns', fd).subscribe({
      next: () => { this.say('Pattern added.'); this.patternForm = { name: '', description: '', category: 'General', scale: 1 }; this.patternFile = undefined; this.load(); },
      error: this.fail,
    });
  }
  togglePattern(p: Pattern) { this.http.put(`/api/admin/patterns/${p._id}`, { active: !p.active }).subscribe({ next: () => this.load(), error: this.fail }); }
  deletePattern(p: Pattern) {
    if (confirm(`Delete pattern "${p.name}"?`)) this.http.delete(`/api/admin/patterns/${p._id}`).subscribe({ next: () => { this.say('Pattern deleted.'); this.load(); }, error: this.fail });
  }

  /* users */
  setRole(u: User, role: string) { this.http.put(`/api/admin/users/${u._id}`, { role }).subscribe({ next: () => { this.say('Role updated.'); this.load(); }, error: (e) => { this.fail(e); this.load(); } }); }
  toggleUser(u: User) { this.http.put(`/api/admin/users/${u._id}`, { active: !u.active }).subscribe({ next: () => this.load(), error: this.fail }); }
  deleteUser(u: User) {
    if (confirm(`Delete ${u.name} and all of their rooms and designs?`)) this.http.delete(`/api/admin/users/${u._id}`).subscribe({ next: () => { this.say('User deleted.'); this.load(); }, error: this.fail });
  }

  /* designs */
  deleteProject(p: Project) {
    if (confirm(`Remove "${p.title}"?`)) this.http.delete(`/api/admin/projects/${p._id}`).subscribe({ next: () => this.load(), error: this.fail });
  }

  /* settings */
  saveSettings() {
    this.http.put<Settings>('/api/admin/settings', this.settings).subscribe({ next: (s) => { this.settings = s; this.say('Settings saved.'); }, error: this.fail });
  }
}
