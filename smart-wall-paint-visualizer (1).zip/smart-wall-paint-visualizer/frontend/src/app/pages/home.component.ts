import { Component, inject, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../core/auth.service';
import { Project } from '../core/models';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink, DatePipe],
  template: `
    <div class="page">
      <div class="row spread head">
        <div>
          <h1>Hello, {{ auth.user()?.name }}</h1>
          <p class="muted">Pick up where you left off, or start with a new room.</p>
        </div>
        <a class="btn primary" routerLink="/upload">Upload a room photo</a>
      </div>

      <div class="grid cols-4 stats">
        <div class="card"><span class="muted">Rooms uploaded</span><strong>{{ projects.length }}</strong></div>
        <div class="card"><span class="muted">Designs saved</span><strong>{{ savedCount }}</strong></div>
        <div class="card"><span class="muted">Design trials</span><strong>{{ trialCount }}</strong></div>
      </div>

      <h2>Recent rooms</h2>
      @if (!loaded) { <p class="muted">Loading…</p> }
      @else if (!projects.length) {
        <div class="card empty">
          <h3>No rooms yet</h3>
          <p>Upload a clear, well-lit photo of a room to start trying colours.</p>
          <a class="btn primary" routerLink="/upload">Upload your first room</a>
        </div>
      } @else {
        <div class="grid cols-4">
          @for (p of projects.slice(0, 4); track p._id) {
            <a class="card proj" [routerLink]="['/editor', p._id]">
              <img class="thumb" [src]="p.thumbnail || p.originalImage.url" [alt]="p.title">
              <h3>{{ p.title }}</h3>
              <span class="muted">Edited {{ p.updatedAt | date: 'mediumDate' }}</span>
            </a>
          }
        </div>
      }

      <h2 class="steps-h">How it works</h2>
      <ol class="steps">
        <li><b>Upload</b> a JPG or PNG photo of your room.</li>
        <li><b>Select</b> each wall with the polygon or brush tool.</li>
        <li><b>Paint</b> with a colour, dual-tone or pattern and adjust opacity.</li>
        <li><b>Compare</b> before and after, then save or download.</li>
      </ol>
    </div>
  `,
  styles: [`
    .head { margin-bottom: 20px; }
    .stats { margin-bottom: 28px; .card { display: flex; flex-direction: column; } strong { font-family: var(--font-head); font-size: 2rem; } }
    .proj { text-decoration: none; color: inherit; display: block; padding: 12px; &:hover { border-color: var(--primary); } h3 { margin: 10px 0 2px; } }
    .steps-h { margin-top: 36px; }
    .steps { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; list-style: none; padding: 0; counter-reset: s; }
    .steps li { counter-increment: s; background: var(--surface); border: 1px solid var(--line); border-radius: 14px; padding: 16px 16px 16px 52px; position: relative; }
    .steps li::before { content: counter(s); position: absolute; left: 14px; top: 14px; width: 26px; height: 26px; border-radius: 50%; background: var(--chip); font-weight: 700; display: grid; place-items: center; }
  `],
})
export class HomeComponent implements OnInit {
  auth = inject(AuthService);
  private http = inject(HttpClient);
  projects: Project[] = [];
  loaded = false;
  get savedCount() { return this.projects.filter((p) => p.saved).length; }
  get trialCount() { return this.projects.reduce((n, p) => n + (p.trials?.length || 0), 0); }

  ngOnInit() {
    this.http.get<Project[]>('/api/projects').subscribe({ next: (p) => { this.projects = p; this.loaded = true; }, error: () => (this.loaded = true) });
  }
}
