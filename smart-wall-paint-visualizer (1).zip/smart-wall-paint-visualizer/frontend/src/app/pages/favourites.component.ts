import { Component, inject, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Color, Pattern, User } from '../core/models';

@Component({
  selector: 'app-favourites',
  standalone: true,
  template: `
    <div class="page">
      <h1>Favourites</h1>
      <p class="muted">Tap the heart on any colour or pattern in the editor to keep it here.</p>

      <h2>Colours</h2>
      @if (!colors.length) { <p class="muted">No favourite colours yet.</p> }
      <div class="grid cols-4">
        @for (c of colors; track c._id) {
          <div class="card row">
            <span class="swatch big" [style.background]="c.hex"></span>
            <div class="grow"><b>{{ c.name }}</b><br><span class="muted">{{ c.code }} · {{ c.hex }} · {{ c.brand }}</span></div>
            <button class="btn small" (click)="toggle('color', c._id)" aria-label="Remove from favourites">Remove</button>
          </div>
        }
      </div>

      <h2 class="gap">Patterns</h2>
      @if (!patterns.length) { <p class="muted">No favourite patterns yet.</p> }
      <div class="grid cols-4">
        @for (p of patterns; track p._id) {
          <div class="card row">
            <img class="tile" [src]="p.imageUrl" [alt]="p.name">
            <div class="grow"><b>{{ p.name }}</b><br><span class="muted">{{ p.category }}</span></div>
            <button class="btn small" (click)="toggle('pattern', p._id)" aria-label="Remove from favourites">Remove</button>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`.big { width: 44px; height: 44px; } .tile { width: 44px; height: 44px; border: 1px solid var(--line); border-radius: 6px; } .gap { margin-top: 28px; }`],
})
export class FavouritesComponent implements OnInit {
  private http = inject(HttpClient);
  private allColors: Color[] = [];
  private allPatterns: Pattern[] = [];
  private favC: string[] = [];
  private favP: string[] = [];
  get colors() { return this.allColors.filter((c) => this.favC.includes(c._id)); }
  get patterns() { return this.allPatterns.filter((p) => this.favP.includes(p._id)); }

  ngOnInit() {
    this.http.get<Color[]>('/api/colors').subscribe((c) => (this.allColors = c));
    this.http.get<Pattern[]>('/api/patterns').subscribe((p) => (this.allPatterns = p));
    this.http.get<User>('/api/auth/me').subscribe((u) => { this.favC = u.favouriteColors; this.favP = u.favouritePatterns; });
  }

  toggle(type: 'color' | 'pattern', id: string) {
    this.http.put<{ favouriteColors: string[]; favouritePatterns: string[] }>('/api/auth/favourites', { type, id }).subscribe((r) => {
      this.favC = r.favouriteColors;
      this.favP = r.favouritePatterns;
    });
  }
}
