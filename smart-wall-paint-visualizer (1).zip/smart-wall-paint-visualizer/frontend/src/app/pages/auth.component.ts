import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../core/auth.service';
import { errorText } from '../core/auth.interceptor';
import { PublicSettings } from '../core/models';

@Component({
  selector: 'app-auth',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <div class="split">
      <section class="intro">
        <h1>See the colour on your own wall before you buy the paint.</h1>
        <p>Upload a photo of your room, mark the walls, and try colours, dual-tones and patterns. Compare before and after, then save or download your favourite look.</p>
        <div class="chips">
          @for (c of chips; track c.name) {
            <div class="chip" [style.background]="c.hex" [style.color]="c.dark ? '#fff' : '#151b2b'"><b>{{ c.name }}</b><span>{{ c.code }}</span></div>
          }
        </div>
      </section>

      <section class="panel">
        <form class="card" (ngSubmit)="submit()">
          <h2>{{ mode === 'login' ? 'Log in' : 'Create your account' }}</h2>
          @if (error) { <div class="alert error" role="alert">{{ error }}</div> }
          @if (mode === 'register') {
            <label class="field">Full name <input type="text" name="name" [(ngModel)]="name" autocomplete="name" required></label>
          }
          <label class="field">Email <input type="email" name="email" [(ngModel)]="email" autocomplete="email" required></label>
          <label class="field">Password
            <input type="password" name="password" [(ngModel)]="password" [autocomplete]="mode === 'login' ? 'current-password' : 'new-password'" required>
            @if (mode === 'register') { <small class="muted">At least 8 characters, with a letter and a number.</small> }
          </label>
          <button class="btn primary full" [disabled]="busy">{{ mode === 'login' ? 'Log in' : 'Create account' }}</button>
          <p class="switch muted">
            @if (mode === 'login') {
              @if (settings?.allowRegistration !== false) { New here? <a routerLink="/register">Create an account</a> } @else { Registration is currently closed. }
            } @else { Already registered? <a routerLink="/login">Log in</a> }
          </p>
        </form>
      </section>
    </div>
  `,
  styles: [`
    .split { min-height: 100vh; display: grid; grid-template-columns: 1.1fr 1fr; }
    .intro { background: #151b2b; color: #fff; padding: 64px 56px; display: flex; flex-direction: column; justify-content: center; gap: 8px; }
    .intro h1 { font-size: 2.6rem; max-width: 18ch; }
    .intro p { color: #c7cde0; max-width: 46ch; font-size: 16px; }
    .chips { display: flex; margin-top: 24px; max-width: 520px; }
    .chip { flex: 1; min-height: 190px; padding: 14px 10px; display: flex; flex-direction: column; justify-content: flex-end; font-size: 12px; transition: flex .25s; }
    .chip b { font-size: 13px; } .chip span { opacity: .8; }
    .chip:hover { flex: 1.8; }
    .panel { display: flex; align-items: center; justify-content: center; padding: 32px 20px; }
    form { width: 100%; max-width: 400px; padding: 28px; }
    .full { width: 100%; justify-content: center; padding: 11px; }
    .switch { margin: 14px 0 0; text-align: center; }
    @media (max-width: 860px) { .split { grid-template-columns: 1fr; } .intro { padding: 36px 24px; } .intro h1 { font-size: 1.9rem; } .chip { min-height: 90px; } }
  `],
})
export class AuthComponent implements OnInit {
  private auth = inject(AuthService);
  private router = inject(Router);
  private http = inject(HttpClient);
  mode: 'login' | 'register' = inject(ActivatedRoute).snapshot.data['mode'];
  name = ''; email = ''; password = '';
  error = ''; busy = false;
  settings?: PublicSettings;
  chips = [
    { name: 'Ocean Breeze Blue', code: 'PV-101', hex: '#7fb7d6', dark: false },
    { name: 'Sage Whisper', code: 'PV-103', hex: '#b7c4a8', dark: false },
    { name: 'Saffron Glow', code: 'PV-110', hex: '#f2b134', dark: false },
    { name: 'Terracotta Clay', code: 'PV-109', hex: '#c8683f', dark: true },
    { name: 'Plum Velvet', code: 'PV-106', hex: '#7a4a6b', dark: true },
  ];

  ngOnInit() {
    if (this.auth.token()) this.router.navigate(['/home']);
    this.http.get<PublicSettings>('/api/settings/public').subscribe({ next: (s) => (this.settings = s), error: () => undefined });
  }

  submit() {
    this.error = '';
    if (!this.email || !this.password || (this.mode === 'register' && !this.name)) {
      this.error = 'Please fill in all fields.';
      return;
    }
    this.busy = true;
    const req = this.mode === 'login' ? this.auth.login(this.email, this.password) : this.auth.register(this.name, this.email, this.password);
    req.subscribe({
      next: (r) => this.router.navigate([r.user.role === 'admin' ? '/admin' : '/home']),
      error: (e) => { this.error = errorText(e, 'Could not reach the server.'); this.busy = false; },
    });
  }
}
