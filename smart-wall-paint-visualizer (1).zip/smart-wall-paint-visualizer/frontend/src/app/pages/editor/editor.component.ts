import { Component, ElementRef, HostListener, OnDestroy, OnInit, ViewChild, inject } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Color, Finish, PaintSettings, Pattern, Project, PublicSettings, Trial, User, Wall } from '../../core/models';
import { errorText } from '../../core/auth.interceptor';

type Tool = 'polygon' | 'brush' | 'select';
type Compare = 'after' | 'before' | 'split';
type Pt = number[];

const MAX_SIDE = 1400; // working resolution of the canvas (keeps rendering fast)

@Component({
  selector: 'app-editor',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './editor.component.html',
  styleUrl: './editor.component.scss',
})
export class EditorComponent implements OnInit, OnDestroy {
  private http = inject(HttpClient);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  @ViewChild('cv', { static: true }) cvRef!: ElementRef<HTMLCanvasElement>;

  project?: Project;
  title = '';
  trials: Trial[] = [];
  activeIdx = 0;
  colors: Color[] = [];
  patterns: Pattern[] = [];
  favC: string[] = [];
  favP: string[] = [];
  disclaimer = '';
  finishes: Finish[] = ['matte', 'satin', 'glossy', 'eggshell'];

  // UI state
  ready = false;
  loadError = '';
  tool: Tool = 'polygon';
  compare: Compare = 'after';
  splitPos = 0.5;
  brushPct = 4; // brush diameter as % of image width
  slot: 'primary' | 'secondary' = 'primary';
  selectedId: string | null = null;
  search = '';
  category = '';
  favOnly = false;
  dirty = false;
  saving = false;
  notice = '';
  noticeKind: 'ok' | 'error' = 'ok';
  menuOpen = false;

  // Current paint settings used for new walls
  paint: PaintSettings = {
    mode: 'solid', color: '#7fb7d6', colorId: null, color2: '#f4f1ea', color2Id: null, splitRatio: 0.5,
    patternId: null, patternScale: 1, finish: 'matte', opacity: 0.85, brightness: 0, blend: 'multiply',
  };

  private img?: HTMLImageElement;
  private patImgs = new Map<string, HTMLImageElement>();
  draft: Pt[] = [];
  private stroke: Pt[] = [];
  private brushing = false;
  private dragIdx = -1;
  private splitDrag = false;
  private cursor: Pt | null = null;
  private hist: string[] = [];
  private hi = -1;
  private raf = 0;
  private noticeTimer?: ReturnType<typeof setTimeout>;

  get cv() { return this.cvRef.nativeElement; }
  get walls(): Wall[] { return this.trials[this.activeIdx]?.walls || []; }
  get selected(): Wall | null { return this.walls.find((w) => w.id === this.selectedId) || null; }
  get cur(): PaintSettings { return this.selected ?? this.paint; }
  get canUndo() { return this.hi > 0; }
  get canRedo() { return this.hi < this.hist.length - 1; }
  get categories() { return [...new Set(this.colors.flatMap((c) => c.categories))].sort(); }
  get filteredColors() {
    const q = this.search.trim().toLowerCase();
    return this.colors.filter((c) =>
      (!q || c.name.toLowerCase().includes(q) || (c.code || '').toLowerCase().includes(q)) &&
      (!this.category || c.categories.includes(this.category)) &&
      (!this.favOnly || this.favC.includes(c._id)));
  }
  get activeColor(): Color | undefined {
    const id = this.slot === 'secondary' ? this.cur.color2Id : this.cur.colorId;
    return this.colors.find((c) => c._id === id);
  }
  get hint(): string {
    if (this.compare !== 'after') return this.compare === 'split' ? 'Drag across the photo to move the before/after divider.' : 'Showing the original photo.';
    if (this.tool === 'polygon') return this.draft.length ? 'Keep clicking corners. Double-click or press Enter to finish, Esc to cancel.' : 'Click the corners of a wall to outline it.';
    if (this.tool === 'brush') return 'Drag over the area to paint. Strokes join the selected brush wall; deselect to start a new one.';
    return 'Click a wall to select it. Drag its corner points to reshape. Right-click a point to remove it.';
  }

  /* ---------- loading ---------- */
  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    this.http.get<Color[]>('/api/colors').subscribe((c) => { this.colors = c; this.syncColorNames(); });
    this.http.get<Pattern[]>('/api/patterns').subscribe((p) => {
      this.patterns = p;
      p.forEach((pt) => this.loadPattern(pt));
    });
    this.http.get<User>('/api/auth/me').subscribe((u) => { this.favC = u.favouriteColors; this.favP = u.favouritePatterns; });
    this.http.get<PublicSettings>('/api/settings/public').subscribe((s) => (this.disclaimer = s.disclaimer));
    this.http.get<Project>(`/api/projects/${id}`).subscribe({
      next: (p) => {
        this.project = p;
        this.title = p.title;
        this.trials = p.trials?.length ? p.trials : [{ name: 'Trial 1', walls: [] }];
        this.activeIdx = Math.min(p.activeTrial || 0, this.trials.length - 1);
        this.loadImage(p.originalImage.url);
      },
      error: () => this.router.navigate(['/saved']),
    });
  }

  ngOnDestroy() {
    cancelAnimationFrame(this.raf);
  }

  private syncColorNames() { /* colours are resolved by id at display time */ }

  private loadImage(url: string) {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      this.img = img;
      const s = Math.min(1, MAX_SIDE / Math.max(img.naturalWidth, img.naturalHeight));
      this.cv.width = Math.round(img.naturalWidth * s);
      this.cv.height = Math.round(img.naturalHeight * s);
      this.ready = true;
      this.resetHistory();
      this.render();
    };
    img.onerror = () => (this.loadError = 'The room photo could not be loaded. Go back to Saved designs and try again.');
    img.src = url;
  }

  private loadPattern(p: Pattern) {
    const im = new Image();
    im.onload = () => this.queue();
    im.src = p.imageUrl;
    this.patImgs.set(p._id, im);
  }

  /* ---------- pointer interaction ---------- */
  private pos(e: PointerEvent): Pt {
    const r = this.cv.getBoundingClientRect();
    return [Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)), Math.min(1, Math.max(0, (e.clientY - r.top) / r.height))];
  }
  private k() { return this.cv.width / this.cv.getBoundingClientRect().width; } // canvas px per CSS px
  private distPx(a: Pt, b: Pt) { return Math.hypot((a[0] - b[0]) * this.cv.width, (a[1] - b[1]) * this.cv.height) / this.k(); }

  onDown(e: PointerEvent) {
    if (!this.ready) return;
    const p = this.pos(e);
    if (this.compare === 'split') { this.splitDrag = true; this.splitPos = p[0]; (e.target as Element).setPointerCapture(e.pointerId); this.queue(); return; }
    if (this.compare === 'before') return;
    if (this.tool === 'polygon') {
      if (this.draft.length >= 3 && this.distPx(p, this.draft[0]) < 12) { this.finishPolygon(); return; }
      this.draft.push(p);
    } else if (this.tool === 'brush') {
      (e.target as Element).setPointerCapture(e.pointerId);
      this.brushing = true;
      this.stroke = [p];
    } else {
      const w = this.selected;
      if (w && w.kind === 'polygon') {
        const i = w.points.findIndex((pt) => this.distPx(pt, p) < 12);
        if (i >= 0) {
          if (e.button === 2 || e.altKey) { if (w.points.length > 3) { w.points.splice(i, 1); this.commit(); } }
          else { this.dragIdx = i; (e.target as Element).setPointerCapture(e.pointerId); }
          return;
        }
      }
      const hit = this.hit(p);
      this.selectedId = hit ? hit.id : null;
    }
    this.queue();
  }

  onMove(e: PointerEvent) {
    if (!this.ready) return;
    const p = this.pos(e);
    this.cursor = p;
    if (this.splitDrag) this.splitPos = p[0];
    else if (this.brushing) {
      const last = this.stroke[this.stroke.length - 1];
      if (this.distPx(p, last) > 3) this.stroke.push(p);
    } else if (this.dragIdx >= 0 && this.selected) this.selected.points[this.dragIdx] = p;
    this.queue();
  }

  onUp() {
    if (this.splitDrag) this.splitDrag = false;
    if (this.brushing) { this.brushing = false; this.finishStroke(); }
    if (this.dragIdx >= 0) { this.dragIdx = -1; this.commit(); }
  }

  onLeave() { this.cursor = null; this.queue(); }

  onDblClick() {
    if (this.tool !== 'polygon' || this.compare !== 'after') return;
    if (this.draft.length >= 4) this.draft.pop(); // drop the duplicate point created by the second click
    if (this.draft.length >= 3) this.finishPolygon();
  }

  @HostListener('document:keydown', ['$event'])
  onKey(e: KeyboardEvent) {
    const t = e.target as HTMLElement;
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(t.tagName) && t.getAttribute('type') !== 'range') return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); this.undo(); }
    else if ((e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === 'y')) { e.preventDefault(); this.redo(); }
    else if (e.key === 'Enter' && this.draft.length >= 3) this.finishPolygon();
    else if (e.key === 'Escape') { this.draft = []; this.stroke = []; this.brushing = false; this.queue(); }
    else if ((e.key === 'Delete' || e.key === 'Backspace') && this.selected && this.tool !== 'polygon') { e.preventDefault(); this.removeWall(this.selected); }
  }

  @HostListener('window:beforeunload', ['$event'])
  onUnload(e: BeforeUnloadEvent) {
    if (this.dirty) { e.preventDefault(); e.returnValue = ''; }
  }

  /* ---------- walls ---------- */
  private newWall(kind: 'polygon' | 'brush'): Wall {
    return {
      ...this.paint,
      id: 'w' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
      name: `Wall ${this.walls.length + 1}`,
      kind, points: [], strokes: [], size: this.brushPct / 200,
    };
  }

  finishPolygon() {
    if (this.draft.length < 3) return;
    const w = this.newWall('polygon');
    w.points = this.draft;
    this.draft = [];
    this.walls.push(w);
    this.selectedId = w.id;
    this.commit();
  }

  private finishStroke() {
    const s = this.stroke;
    this.stroke = [];
    if (!s.length) return;
    const sel = this.selected;
    if (sel && sel.kind === 'brush') sel.strokes.push(s);
    else {
      const w = this.newWall('brush');
      w.strokes = [s];
      this.walls.push(w);
      this.selectedId = w.id;
    }
    this.commit();
  }

  removeWall(w: Wall) {
    const t = this.trials[this.activeIdx];
    t.walls = t.walls.filter((x) => x.id !== w.id);
    if (this.selectedId === w.id) this.selectedId = null;
    this.commit();
  }

  renameWall(w: Wall) {
    const n = prompt('Wall name', w.name);
    if (n && n.trim()) { w.name = n.trim().slice(0, 40); this.commit(); }
  }

  select(w: Wall) { this.selectedId = w.id; this.tool = 'select'; this.queue(); }
  deselect() { this.selectedId = null; this.queue(); }

  setTool(t: Tool) { this.tool = t; this.draft = []; this.stroke = []; this.compare = 'after'; this.queue(); }
  setCompare(c: Compare) { this.compare = c; this.queue(); }

  private hit(p: Pt): Wall | null {
    const W = this.cv.width, H = this.cv.height;
    for (let i = this.walls.length - 1; i >= 0; i--) {
      const w = this.walls[i];
      if (w.kind === 'polygon') { if (this.inPoly(p, w.points)) return w; }
      else {
        const r = w.size * W;
        for (const s of w.strokes) {
          for (let j = 0; j < s.length; j++) {
            const a = s[j], b = s[j + 1] || s[j];
            if (this.segDist(p[0] * W, p[1] * H, a[0] * W, a[1] * H, b[0] * W, b[1] * H) <= r) return w;
          }
        }
      }
    }
    return null;
  }
  private inPoly(p: Pt, pts: Pt[]) {
    let inside = false;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const [xi, yi] = pts[i], [xj, yj] = pts[j];
      if ((yi > p[1]) !== (yj > p[1]) && p[0] < ((xj - xi) * (p[1] - yi)) / (yj - yi) + xi) inside = !inside;
    }
    return inside;
  }
  private segDist(px: number, py: number, ax: number, ay: number, bx: number, by: number) {
    const dx = bx - ax, dy = by - ay;
    const t = dx || dy ? Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy))) : 0;
    return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
  }

  /* ---------- paint settings ---------- */
  setProp<K extends keyof PaintSettings>(key: K, value: PaintSettings[K]) {
    this.paint[key] = value;
    const w = this.selected;
    if (w) { (w as PaintSettings)[key] = value; this.dirty = true; }
    this.queue();
  }

  setMode(m: 'solid' | 'dual' | 'pattern') {
    this.slot = 'primary';
    this.setProp('mode', m);
    if (m === 'pattern' && !this.cur.patternId && this.patterns.length) this.setProp('patternId', this.patterns[0]._id);
    this.commit();
  }

  setBrush(pct: number) {
    this.brushPct = pct;
    const w = this.selected;
    if (w && w.kind === 'brush') { w.size = pct / 200; this.queue(); }
  }

  pickColor(c: Color) {
    if (this.slot === 'secondary' && this.cur.mode === 'dual') { this.setProp('color2', c.hex); this.setProp('color2Id', c._id); }
    else {
      this.setProp('color', c.hex); this.setProp('colorId', c._id);
      if (!c.finishes.includes(this.cur.finish)) this.setProp('finish', c.finishes[0] || 'matte');
    }
    this.commit();
  }

  pickCustom(hex: string, final: boolean) {
    if (this.slot === 'secondary' && this.cur.mode === 'dual') { this.setProp('color2', hex); this.setProp('color2Id', null); }
    else { this.setProp('color', hex); this.setProp('colorId', null); }
    if (final) this.commit();
  }

  pickPattern(p: Pattern) {
    this.setProp('patternId', p._id);
    this.setProp('patternScale', p.scale || 1);
    this.commit();
  }

  colorName(hex: string, id: string | null) {
    const c = this.colors.find((x) => x._id === id);
    return c ? `${c.name} (${c.code || c.hex})` : hex.toUpperCase();
  }

  toggleFav(type: 'color' | 'pattern', id: string, ev: Event) {
    ev.stopPropagation();
    this.http.put<{ favouriteColors: string[]; favouritePatterns: string[] }>('/api/auth/favourites', { type, id }).subscribe((r) => {
      this.favC = r.favouriteColors;
      this.favP = r.favouritePatterns;
    });
  }

  /* ---------- trials ---------- */
  switchTrial(i: number) {
    this.activeIdx = i; this.selectedId = null; this.draft = []; this.resetHistory(); this.queue(); this.dirty = true;
  }
  addTrial() {
    this.trials.push({ name: `Trial ${this.trials.length + 1}`, walls: [] });
    this.switchTrial(this.trials.length - 1);
  }
  duplicateTrial() {
    const copy = JSON.parse(JSON.stringify(this.trials[this.activeIdx])) as Trial;
    copy.name = `${copy.name} copy`.slice(0, 40);
    this.trials.push(copy);
    this.switchTrial(this.trials.length - 1);
  }
  renameTrial() {
    const n = prompt('Trial name', this.trials[this.activeIdx].name);
    if (n && n.trim()) { this.trials[this.activeIdx].name = n.trim().slice(0, 40); this.dirty = true; }
  }
  deleteTrial() {
    if (this.trials.length < 2 || !confirm('Delete this trial?')) return;
    this.trials.splice(this.activeIdx, 1);
    this.switchTrial(Math.max(0, this.activeIdx - 1));
  }

  /* ---------- history ---------- */
  private resetHistory() { this.hist = [JSON.stringify(this.walls)]; this.hi = 0; }
  commit() {
    this.hist = this.hist.slice(0, this.hi + 1);
    this.hist.push(JSON.stringify(this.walls));
    if (this.hist.length > 60) this.hist.shift();
    this.hi = this.hist.length - 1;
    this.dirty = true;
    this.queue();
  }
  undo() { if (this.canUndo) this.restore(--this.hi); }
  redo() { if (this.canRedo) this.restore(++this.hi); }
  private restore(i: number) {
    this.trials[this.activeIdx].walls = JSON.parse(this.hist[i]);
    if (!this.selected) this.selectedId = null;
    this.dirty = true;
    this.queue();
  }
  clearAll() {
    if (!this.walls.length || !confirm('Remove all painted walls in this trial?')) return;
    this.trials[this.activeIdx].walls = [];
    this.selectedId = null;
    this.commit();
  }

  /* ---------- rendering ---------- */
  queue() {
    if (this.raf) return;
    this.raf = requestAnimationFrame(() => { this.raf = 0; this.render(); });
  }

  private render() {
    if (!this.img) return;
    const c = this.cv, ctx = c.getContext('2d')!;
    const W = c.width, H = c.height;
    ctx.clearRect(0, 0, W, H);
    ctx.drawImage(this.img, 0, 0, W, H);
    if (this.compare !== 'before') this.paintWalls(ctx, W, H, this.walls);
    if (this.compare === 'split') {
      ctx.save();
      ctx.beginPath(); ctx.rect(0, 0, W * this.splitPos, H); ctx.clip();
      ctx.drawImage(this.img, 0, 0, W, H);
      ctx.restore();
      const x = W * this.splitPos, k = this.k();
      ctx.fillStyle = '#fff'; ctx.fillRect(x - k, 0, 2 * k, H);
      ctx.beginPath(); ctx.arc(x, H / 2, 14 * k, 0, 7); ctx.fillStyle = '#fff'; ctx.fill();
      ctx.fillStyle = '#151b2b'; ctx.font = `${12 * k}px sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('⇄', x, H / 2);
      this.label(ctx, 'Before', 12 * k, 12 * k, k); this.label(ctx, 'After', W - 12 * k, 12 * k, k, true);
    }
    if (this.compare === 'after') this.overlay(ctx, W, H);
  }

  private label(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, k: number, right = false) {
    ctx.font = `600 ${13 * k}px sans-serif`;
    const w = ctx.measureText(text).width + 16 * k;
    const bx = right ? x - w : x;
    ctx.fillStyle = 'rgba(21,27,43,.8)'; ctx.fillRect(bx, y, w, 26 * k);
    ctx.fillStyle = '#fff'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(text, bx + 8 * k, y + 13 * k);
  }

  private mkCanvas(W: number, H: number) {
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    return c;
  }

  private maskFor(w: Wall, W: number, H: number) {
    const m = this.mkCanvas(W, H), g = m.getContext('2d')!;
    g.filter = 'blur(0.7px)'; // soft edge so the paint blends into the photo
    g.fillStyle = '#000'; g.strokeStyle = '#000';
    if (w.kind === 'polygon') {
      g.beginPath();
      w.points.forEach((p, i) => (i ? g.lineTo(p[0] * W, p[1] * H) : g.moveTo(p[0] * W, p[1] * H)));
      g.closePath(); g.fill();
    } else {
      g.lineWidth = w.size * 2 * W; g.lineCap = 'round'; g.lineJoin = 'round';
      for (const s of w.strokes) {
        g.beginPath();
        s.forEach((p, i) => (i ? g.lineTo(p[0] * W, p[1] * H) : g.moveTo(p[0] * W, p[1] * H)));
        if (s.length === 1) g.lineTo(s[0][0] * W + 0.01, s[0][1] * H);
        g.stroke();
      }
    }
    return m;
  }

  private bounds(w: Wall): { minY: number; maxY: number } {
    const ys = w.kind === 'polygon' ? w.points.map((p) => p[1]) : w.strokes.flat().map((p) => p[1]);
    return { minY: Math.min(...ys), maxY: Math.max(...ys) };
  }

  /** Paints every wall onto ctx. Colour layers are blended into the photo so shadows and light remain visible. */
  private paintWalls(ctx: CanvasRenderingContext2D, W: number, H: number, walls: Wall[]) {
    for (const w of walls) {
      const layer = this.mkCanvas(W, H), l = layer.getContext('2d')!;
      l.fillStyle = w.color; l.fillRect(0, 0, W, H);
      if (w.mode === 'dual') {
        const b = this.bounds(w);
        const splitY = (b.maxY - (b.maxY - b.minY) * w.splitRatio) * H; // lower part keeps colour 1, upper part gets colour 2
        l.fillStyle = w.color2; l.fillRect(0, 0, W, splitY);
        l.fillStyle = 'rgba(0,0,0,.18)'; l.fillRect(0, splitY - 1, W, 2); // fine dado line
      }
      if (w.mode === 'pattern') {
        const im = w.patternId ? this.patImgs.get(w.patternId) : undefined;
        if (im && im.complete && im.naturalWidth) {
          const pat = l.createPattern(im, 'repeat');
          if (pat) {
            pat.setTransform(new DOMMatrix().scale((W / 1000) * w.patternScale));
            l.globalCompositeOperation = 'multiply'; l.fillStyle = pat; l.fillRect(0, 0, W, H);
            l.globalCompositeOperation = 'source-over';
          }
        }
      }
      if (w.brightness) { l.fillStyle = w.brightness > 0 ? `rgba(255,255,255,${w.brightness / 100})` : `rgba(0,0,0,${-w.brightness / 100})`; l.fillRect(0, 0, W, H); }
      const sheen = { matte: 0, eggshell: 0.06, satin: 0.12, glossy: 0.24 }[w.finish];
      if (sheen) {
        const g = l.createLinearGradient(0, 0, W, H);
        g.addColorStop(0, `rgba(255,255,255,${sheen})`); g.addColorStop(0.5, 'rgba(255,255,255,0)'); g.addColorStop(1, `rgba(255,255,255,${sheen / 2})`);
        l.fillStyle = g; l.fillRect(0, 0, W, H);
      }
      l.globalCompositeOperation = 'destination-in';
      l.drawImage(this.maskFor(w, W, H), 0, 0);
      ctx.save();
      ctx.globalAlpha = w.opacity;
      ctx.globalCompositeOperation = w.blend === 'color' ? 'color' : 'multiply';
      ctx.drawImage(layer, 0, 0);
      ctx.restore();
    }
  }

  private overlay(ctx: CanvasRenderingContext2D, W: number, H: number) {
    const k = this.k();
    const path = (pts: Pt[], close: boolean) => {
      ctx.beginPath();
      pts.forEach((p, i) => (i ? ctx.lineTo(p[0] * W, p[1] * H) : ctx.moveTo(p[0] * W, p[1] * H)));
      if (close) ctx.closePath();
    };
    const outline = (pts: Pt[], close: boolean, strong: boolean) => {
      path(pts, close);
      ctx.lineWidth = (strong ? 3.5 : 2) * k; ctx.strokeStyle = '#fff'; ctx.setLineDash([]); ctx.stroke();
      ctx.lineWidth = (strong ? 1.8 : 1) * k; ctx.strokeStyle = strong ? '#2f3fd0' : 'rgba(47,63,208,.7)'; ctx.setLineDash(strong ? [] : [6 * k, 5 * k]); ctx.stroke(); ctx.setLineDash([]);
    };
    const dot = (p: Pt, fill: string) => {
      ctx.beginPath(); ctx.arc(p[0] * W, p[1] * H, 6 * k, 0, Math.PI * 2);
      ctx.fillStyle = fill; ctx.fill(); ctx.lineWidth = 2 * k; ctx.strokeStyle = '#2f3fd0'; ctx.stroke();
    };
    for (const w of this.walls) {
      if (w.kind === 'polygon') outline(w.points, true, w.id === this.selectedId);
      else if (w.id === this.selectedId) {
        ctx.save(); ctx.strokeStyle = 'rgba(47,63,208,.35)'; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.lineWidth = w.size * 2 * W + 6 * k;
        for (const s of w.strokes) { path(s, false); ctx.stroke(); }
        ctx.restore();
      }
    }
    const sel = this.selected;
    if (sel && sel.kind === 'polygon' && this.tool === 'select') sel.points.forEach((p) => dot(p, '#fff'));
    if (this.draft.length) {
      const pts = this.cursor ? [...this.draft, this.cursor] : this.draft;
      outline(pts, false, true);
      this.draft.forEach((p, i) => dot(p, i === 0 ? '#ffc13b' : '#fff'));
    }
    if (this.brushing && this.stroke.length) {
      ctx.save(); ctx.strokeStyle = 'rgba(47,63,208,.45)'; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.lineWidth = (this.selected?.kind === 'brush' ? this.selected.size : this.brushPct / 200) * 2 * W;
      path(this.stroke.length === 1 ? [this.stroke[0], [this.stroke[0][0] + 0.0001, this.stroke[0][1]]] : this.stroke, false); ctx.stroke(); ctx.restore();
    }
    if (this.tool === 'brush' && this.cursor) {
      ctx.beginPath(); ctx.arc(this.cursor[0] * W, this.cursor[1] * H, (this.brushPct / 200) * W, 0, Math.PI * 2);
      ctx.lineWidth = 1.5 * k; ctx.strokeStyle = '#fff'; ctx.stroke();
      ctx.lineWidth = 0.8 * k; ctx.strokeStyle = '#151b2b'; ctx.stroke();
    }
  }

  /* ---------- save / export ---------- */
  private renderExport(width?: number): HTMLCanvasElement {
    const W = width || this.cv.width, H = Math.round((W * this.cv.height) / this.cv.width);
    const c = this.mkCanvas(W, H), ctx = c.getContext('2d')!;
    ctx.drawImage(this.img!, 0, 0, W, H);
    this.paintWalls(ctx, W, H, this.walls);
    return c;
  }

  save() {
    if (!this.project || !this.ready) return;
    this.saving = true;
    const thumbnail = this.renderExport(480).toDataURL('image/jpeg', 0.75);
    this.http.put<Project>(`/api/projects/${this.project._id}`, {
      title: this.title, trials: this.trials, activeTrial: this.activeIdx, thumbnail, saved: true,
    }).subscribe({
      next: (p) => { this.dirty = false; this.saving = false; this.trials = p.trials; this.activeIdx = Math.min(this.activeIdx, p.trials.length - 1); this.say('Design saved.'); },
      error: (e) => { this.saving = false; this.say(errorText(e, 'Could not save the design.'), 'error'); },
    });
  }

  download(kind: 'after' | 'compare') {
    this.menuOpen = false;
    if (!this.ready || !this.project) return;
    let out: HTMLCanvasElement;
    const after = this.renderExport();
    if (kind === 'after') out = after;
    else {
      const W = after.width, H = after.height, bar = 44;
      out = this.mkCanvas(W * 2 + 12, H + bar);
      const o = out.getContext('2d')!;
      o.fillStyle = '#fff'; o.fillRect(0, 0, out.width, out.height);
      o.drawImage(this.img!, 0, bar, W, H);
      o.drawImage(after, W + 12, bar);
      o.fillStyle = '#151b2b'; o.font = '600 22px sans-serif'; o.textBaseline = 'middle';
      o.fillText('Before', 12, bar / 2); o.fillText(`After - ${this.trials[this.activeIdx].name}`, W + 24, bar / 2);
    }
    out.toBlob((blob) => {
      if (!blob) return;
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `${(this.title || 'room').replace(/[^\w-]+/g, '_')}-${kind === 'after' ? 'painted' : 'before-after'}.png`;
      a.click();
      URL.revokeObjectURL(a.href);
      this.http.post(`/api/projects/${this.project!._id}/downloaded`, {}).subscribe({ error: () => undefined });
    }, 'image/png');
  }

  private say(text: string, kind: 'ok' | 'error' = 'ok') {
    this.notice = text; this.noticeKind = kind;
    clearTimeout(this.noticeTimer);
    this.noticeTimer = setTimeout(() => (this.notice = ''), 3500);
  }

  num(e: Event) { return +(e.target as HTMLInputElement).value; }
  val(e: Event) { return (e.target as HTMLInputElement).value; }
}
