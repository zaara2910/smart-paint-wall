import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from './core/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    @if (auth.user(); as u) {
      <header class="nav">
        <a routerLink="/home" class="brand"><span class="mark"><i></i><i></i></span>Wall Paint Visualizer</a>
        <nav>
          <a routerLink="/home" routerLinkActive="on">Home</a>
          <a routerLink="/upload" routerLinkActive="on">New room</a>
          <a routerLink="/saved" routerLinkActive="on">Saved designs</a>
          <a routerLink="/favourites" routerLinkActive="on">Favourites</a>
          <a routerLink="/help" routerLinkActive="on">Help</a>
          @if (auth.isAdmin()) { <a routerLink="/admin" routerLinkActive="on">Admin</a> }
        </nav>
        <div class="who">
          <span>{{ u.name }}</span>
          <button class="btn small" (click)="auth.logout()">Log out</button>
        </div>
      </header>
    }
    <router-outlet />
  `,
  styles: [`
    .nav { background: #151b2b; color: #fff; display: flex; align-items: center; gap: 24px; padding: 0 20px; min-height: 56px; flex-wrap: wrap; position: sticky; top: 0; z-index: 20; }
    .brand { color: #fff; text-decoration: none; font-family: var(--font-head); font-weight: 700; font-size: 17px; display: flex; align-items: center; gap: 10px; }
    .mark { display: inline-flex; gap: 2px; i { width: 9px; height: 20px; background: var(--chip); display: block; &:last-child { background: #fff; } } }
    nav { display: flex; gap: 4px; flex: 1; flex-wrap: wrap; }
    nav a { color: #c7cde0; text-decoration: none; padding: 7px 12px; border-radius: 8px; font-weight: 500; }
    nav a:hover { color: #fff; background: #242c42; }
    nav a.on { color: #fff; background: #2f3fd0; }
    .who { display: flex; align-items: center; gap: 12px; font-size: 14px; color: #c7cde0; }
    .who .btn { background: transparent; color: #fff; border-color: #475072; }
  `],
})
export class AppComponent {
  auth = inject(AuthService);
}
