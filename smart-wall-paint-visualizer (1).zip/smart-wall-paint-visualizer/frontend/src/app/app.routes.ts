import { Routes } from '@angular/router';
import { adminGuard, authGuard } from './core/guards';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'home' },
  { path: 'login', data: { mode: 'login' }, loadComponent: () => import('./pages/auth.component').then((m) => m.AuthComponent) },
  { path: 'register', data: { mode: 'register' }, loadComponent: () => import('./pages/auth.component').then((m) => m.AuthComponent) },
  { path: 'home', canActivate: [authGuard], loadComponent: () => import('./pages/home.component').then((m) => m.HomeComponent) },
  { path: 'upload', canActivate: [authGuard], loadComponent: () => import('./pages/upload.component').then((m) => m.UploadComponent) },
  { path: 'editor/:id', canActivate: [authGuard], loadComponent: () => import('./pages/editor/editor.component').then((m) => m.EditorComponent) },
  { path: 'saved', canActivate: [authGuard], loadComponent: () => import('./pages/saved.component').then((m) => m.SavedComponent) },
  { path: 'favourites', canActivate: [authGuard], loadComponent: () => import('./pages/favourites.component').then((m) => m.FavouritesComponent) },
  { path: 'help', canActivate: [authGuard], loadComponent: () => import('./pages/help.component').then((m) => m.HelpComponent) },
  { path: 'admin', canActivate: [authGuard, adminGuard], loadComponent: () => import('./pages/admin/admin.component').then((m) => m.AdminComponent) },
  { path: '**', redirectTo: 'home' },
];
