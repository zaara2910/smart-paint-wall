export interface User {
  _id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  permissions: string[];
  favouriteColors: string[];
  favouritePatterns: string[];
  active: boolean;
  createdAt: string;
  lastLoginAt?: string;
  projectCount?: number;
  savedCount?: number;
}

export interface Color {
  _id: string;
  name: string;
  code?: string;
  hex: string;
  rgb?: { r: number; g: number; b: number };
  brand: string;
  finishes: Finish[];
  categories: string[];
  swatch?: string;
  active: boolean;
}

export interface Pattern {
  _id: string;
  name: string;
  description: string;
  category: string;
  imageUrl: string;
  scale: number;
  active: boolean;
}

export type Finish = 'matte' | 'satin' | 'glossy' | 'eggshell';

/** One painted area of the room photo. Coordinates are normalised (0-1) so they survive any image size. */
export interface Wall {
  id: string;
  name: string;
  kind: 'polygon' | 'brush';
  points: number[][]; // polygon vertices
  strokes: number[][][]; // brush strokes (each a polyline)
  size: number; // brush radius as a fraction of image width
  mode: 'solid' | 'dual' | 'pattern';
  color: string;
  colorId: string | null;
  color2: string;
  color2Id: string | null;
  splitRatio: number; // dual-tone: share of the wall height painted with the lower colour
  patternId: string | null;
  patternScale: number;
  finish: Finish;
  opacity: number;
  brightness: number;
  blend: 'multiply' | 'color';
}

export type PaintSettings = Omit<Wall, 'id' | 'name' | 'kind' | 'points' | 'strokes' | 'size'>;

export interface Trial {
  name: string;
  walls: Wall[];
  updatedAt?: string;
}

export interface Project {
  _id: string;
  title: string;
  originalImage: { url: string; width?: number; height?: number };
  trials: Trial[];
  activeTrial: number;
  thumbnail: string;
  saved: boolean;
  createdAt: string;
  updatedAt: string;
  user?: { _id: string; name: string; email: string };
}

export interface PublicSettings {
  siteName: string;
  maxUploadMB: number;
  allowRegistration: boolean;
  disclaimer: string;
}
