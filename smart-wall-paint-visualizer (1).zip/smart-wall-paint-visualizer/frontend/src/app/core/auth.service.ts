import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs';
import { User } from './models';

interface AuthResponse {
  token: string;
  user: User;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private router = inject(Router);

  user = signal<User | null>(JSON.parse(localStorage.getItem('swpv_user') || 'null'));
  isAdmin = computed(() => this.user()?.role === 'admin');
  private sessionStart = Date.now();

  constructor() {
    // Report time spent in the app (feeds the "average session duration" KPI)
    addEventListener('pagehide', () => this.flushSession());
  }

  token(): string | null {
    return localStorage.getItem('swpv_token');
  }

  login(email: string, password: string) {
    return this.http.post<AuthResponse>('/api/auth/login', { email, password }).pipe(tap((r) => this.setSession(r)));
  }

  register(name: string, email: string, password: string) {
    return this.http.post<AuthResponse>('/api/auth/register', { name, email, password }).pipe(tap((r) => this.setSession(r)));
  }

  logout() {
    this.flushSession();
    localStorage.removeItem('swpv_token');
    localStorage.removeItem('swpv_user');
    this.user.set(null);
    this.router.navigate(['/login']);
  }

  private setSession(r: AuthResponse) {
    localStorage.setItem('swpv_token', r.token);
    localStorage.setItem('swpv_user', JSON.stringify(r.user));
    this.user.set(r.user);
    this.sessionStart = Date.now();
  }

  private flushSession() {
    const token = this.token();
    const seconds = Math.round((Date.now() - this.sessionStart) / 1000);
    this.sessionStart = Date.now();
    if (!token || seconds < 5) return;
    fetch('/api/auth/session', {
      method: 'POST',
      keepalive: true,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ seconds }),
    }).catch(() => undefined);
  }
}
