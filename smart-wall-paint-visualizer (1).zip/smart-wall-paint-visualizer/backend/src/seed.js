// Usage: npm run seed          (adds admin, demo user, colours, patterns if missing)
//        npm run seed:reset    (wipes colours + patterns first)
require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Color = require('./models/Color');
const Pattern = require('./models/Pattern');
const { updateSettings, DEFAULTS } = require('./utils/settings');

const svg = (w, h, body) =>
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><rect width="${w}" height="${h}" fill="#fff"/>${body}</svg>`);

// Light-grey textures: they are multiplied over the chosen paint colour so the colour stays visible
const PATTERNS = [
  { name: 'Vertical Stripes', category: 'Stripes', description: 'Classic even stripes for living rooms and halls.', w: 60, h: 60,
    body: '<rect x="0" width="30" height="60" fill="#d6d6d6"/>' },
  { name: 'Floral Bloom', category: 'Floral', description: 'Soft five-petal flowers on a light ground.', w: 90, h: 90,
    body: '<g fill="#d9d9d9"><circle cx="45" cy="30" r="12"/><circle cx="60" cy="45" r="12"/><circle cx="45" cy="60" r="12"/><circle cx="30" cy="45" r="12"/></g><circle cx="45" cy="45" r="8" fill="#bdbdbd"/>' },
  { name: 'Diamond Lattice', category: 'Geometric', description: 'Repeating diamonds for an accent wall.', w: 80, h: 80,
    body: '<path d="M40 4 L76 40 L40 76 L4 40 Z" fill="none" stroke="#c4c4c4" stroke-width="4"/><path d="M40 24 L56 40 L40 56 L24 40 Z" fill="#dcdcdc"/>' },
  { name: 'Chevron', category: 'Geometric', description: 'Zig-zag chevrons that add movement to a wall.', w: 80, h: 40,
    body: '<polyline points="0,30 20,10 40,30 60,10 80,30" fill="none" stroke="#c8c8c8" stroke-width="8"/>' },
  { name: 'Polka Dots', category: 'Playful', description: 'Friendly dots, ideal for kids rooms.', w: 50, h: 50,
    body: '<circle cx="12" cy="12" r="7" fill="#cfcfcf"/><circle cx="37" cy="37" r="7" fill="#cfcfcf"/>' },
  { name: 'Brick Wall', category: 'Texture', description: 'Light brick effect for an industrial look.', w: 80, h: 40,
    body: '<g fill="none" stroke="#c2c2c2" stroke-width="3"><rect x="0" y="0" width="40" height="20"/><rect x="40" y="0" width="40" height="20"/><rect x="-20" y="20" width="40" height="20"/><rect x="20" y="20" width="40" height="20"/><rect x="60" y="20" width="40" height="20"/></g>' },
];

// [name, code, hex, categories]
const COLORS = [
  ['Ocean Breeze Blue', 'PV-101', '#7fb7d6', ['Living Room', 'Calm']],
  ['Sea Glass', 'PV-102', '#a8d5ca', ['Bathroom', 'Calm']],
  ['Sage Whisper', 'PV-103', '#b7c4a8', ['Bedroom', 'Calm']],
  ['Olive Grove', 'PV-104', '#8b946a', ['Living Room', 'Accent']],
  ['Misty Lavender', 'PV-105', '#c9bfe0', ['Bedroom', 'Calm']],
  ['Plum Velvet', 'PV-106', '#7a4a6b', ['Accent', 'Bold']],
  ['Blush Petal', 'PV-107', '#f2c9c4', ['Bedroom', 'Kids Room']],
  ['Coral Sunrise', 'PV-108', '#f08a6c', ['Accent', 'Bold']],
  ['Terracotta Clay', 'PV-109', '#c8683f', ['Living Room', 'Accent']],
  ['Saffron Glow', 'PV-110', '#f2b134', ['Kitchen', 'Bold']],
  ['Butter Cream', 'PV-111', '#f6e7b4', ['Kitchen', 'Dining']],
  ['Lemon Zest', 'PV-112', '#f4e04d', ['Kids Room', 'Bold']],
  ['Mint Fresh', 'PV-113', '#c6ecd9', ['Kids Room', 'Kitchen']],
  ['Forest Canopy', 'PV-114', '#2f5d46', ['Study', 'Accent']],
  ['Teal Lagoon', 'PV-115', '#2a8f93', ['Living Room', 'Accent']],
  ['Midnight Navy', 'PV-116', '#1f2f56', ['Study', 'Bold']],
  ['Sky Whisper', 'PV-117', '#d4e6f5', ['Bedroom', 'Calm']],
  ['Dusty Rose', 'PV-118', '#d8a7a7', ['Bedroom', 'Living Room']],
  ['Warm Sand', 'PV-119', '#e0cfb1', ['Living Room', 'Neutral']],
  ['Greige Stone', 'PV-120', '#bdb5a8', ['Living Room', 'Neutral']],
  ['Charcoal Slate', 'PV-121', '#4a4f57', ['Study', 'Bold']],
  ['Pearl White', 'PV-122', '#f4f1ea', ['Neutral', 'Living Room']],
  ['Ivory Silk', 'PV-123', '#efe6d2', ['Neutral', 'Dining']],
  ['Peach Nectar', 'PV-124', '#f7c5a1', ['Dining', 'Kitchen']],
  ['Burnt Orange', 'PV-125', '#d9702b', ['Accent', 'Bold']],
  ['Cherry Red', 'PV-126', '#b3263a', ['Dining', 'Bold']],
  ['Turquoise Pool', 'PV-127', '#4fc3c7', ['Bathroom', 'Kids Room']],
  ['Lilac Haze', 'PV-128', '#b9a3d6', ['Bedroom', 'Accent']],
];
const BRANDS = ['ColorCraft', 'ShadeWorks', 'HueHome'];

(async () => {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/smart_wall_paint');
  if (process.argv.includes('--reset')) {
    await Color.deleteMany({});
    await Pattern.deleteMany({});
  }

  const adminEmail = (process.env.ADMIN_EMAIL || 'admin@paintvisualizer.com').toLowerCase();
  if (!(await User.findOne({ email: adminEmail }))) {
    await User.create({
      name: process.env.ADMIN_NAME || 'Site Admin',
      email: adminEmail,
      passwordHash: await bcrypt.hash(process.env.ADMIN_PASSWORD || 'Admin@12345', 12),
      role: 'admin',
      permissions: ['manage_colors', 'manage_patterns', 'manage_users', 'view_activity', 'manage_settings'],
    });
    console.log(`Admin created: ${adminEmail}`);
  }
  if (!(await User.findOne({ email: 'demo@paintvisualizer.com' }))) {
    await User.create({ name: 'Demo User', email: 'demo@paintvisualizer.com', passwordHash: await bcrypt.hash('Demo@12345', 12) });
    console.log('Demo user created: demo@paintvisualizer.com / Demo@12345');
  }

  if ((await Color.countDocuments()) === 0) {
    for (let i = 0; i < COLORS.length; i++) {
      const [name, code, hex, categories] = COLORS[i];
      await Color.create({ name, code, hex, categories, brand: BRANDS[i % BRANDS.length], finishes: ['matte', 'satin', 'glossy', 'eggshell'] });
    }
    console.log(`${COLORS.length} colours added`);
  }
  if ((await Pattern.countDocuments()) === 0) {
    await Pattern.insertMany(PATTERNS.map((p) => ({ name: p.name, category: p.category, description: p.description, imageUrl: svg(p.w, p.h, p.body), width: p.w, height: p.h, scale: 1 })));
    console.log(`${PATTERNS.length} patterns added`);
  }
  await updateSettings(DEFAULTS);
  console.log('Seed complete');
  await mongoose.disconnect();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
