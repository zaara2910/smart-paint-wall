const express = require('express');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const { sign, protect } = require('../middleware/auth');
const wrap = require('../utils/wrap');
const log = require('../utils/activity');
const { getSettings } = require('../utils/settings');

const router = express.Router();
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const bad = (res, message, status = 400) => res.status(status).json({ message });
const strongEnough = (p) => typeof p === 'string' && p.length >= 8 && p.length <= 72 && /[A-Za-z]/.test(p) && /\d/.test(p);

router.post('/register', wrap(async (req, res) => {
  const settings = await getSettings();
  if (!settings.allowRegistration) return bad(res, 'Registration is currently closed', 403);
  const { name, email, password } = req.body;
  if (typeof name !== 'string' || name.trim().length < 2) return bad(res, 'Enter your name (at least 2 characters)');
  if (typeof email !== 'string' || !EMAIL.test(email)) return bad(res, 'Enter a valid email address');
  if (!strongEnough(password)) return bad(res, 'Password must be 8+ characters with at least one letter and one number');
  if (await User.findOne({ email: email.toLowerCase().trim() })) return bad(res, 'An account with this email already exists', 409);
  const user = await User.create({
    name: name.trim(),
    email: email.toLowerCase().trim(),
    passwordHash: await bcrypt.hash(password, 12),
  });
  log(user._id, 'register');
  res.status(201).json({ token: sign(user), user });
}));

router.post('/login', wrap(async (req, res) => {
  const { email, password } = req.body;
  if (typeof email !== 'string' || typeof password !== 'string') return bad(res, 'Email and password are required');
  const user = await User.findOne({ email: email.toLowerCase().trim() });
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) return bad(res, 'Incorrect email or password', 401);
  if (!user.active) return bad(res, 'This account has been deactivated', 403);
  user.lastLoginAt = new Date();
  await user.save();
  log(user._id, 'login');
  res.json({ token: sign(user), user });
}));

router.get('/me', protect, wrap(async (req, res) => res.json(req.user)));

router.put('/me', protect, wrap(async (req, res) => {
  const { name, currentPassword, newPassword } = req.body;
  if (name !== undefined) {
    if (typeof name !== 'string' || name.trim().length < 2) return bad(res, 'Enter a valid name');
    req.user.name = name.trim();
  }
  if (newPassword) {
    if (!(await bcrypt.compare(String(currentPassword || ''), req.user.passwordHash))) return bad(res, 'Current password is incorrect', 401);
    if (!strongEnough(newPassword)) return bad(res, 'New password must be 8+ characters with a letter and a number');
    req.user.passwordHash = await bcrypt.hash(newPassword, 12);
  }
  await req.user.save();
  res.json(req.user);
}));

// Toggle a favourite colour or pattern: { type: 'color' | 'pattern', id }
router.put('/favourites', protect, wrap(async (req, res) => {
  const { type, id } = req.body;
  const field = type === 'pattern' ? 'favouritePatterns' : type === 'color' ? 'favouriteColors' : null;
  if (!field || !id) return bad(res, 'type and id are required');
  const list = req.user[field].map(String);
  req.user[field] = list.includes(String(id)) ? list.filter((x) => x !== String(id)) : [...list, String(id)];
  await req.user.save();
  res.json({ favouriteColors: req.user.favouriteColors, favouritePatterns: req.user.favouritePatterns });
}));

// Time spent in the app (used for the "average session duration" KPI)
router.post('/session', protect, wrap(async (req, res) => {
  const seconds = Math.round(Number(req.body.seconds));
  if (Number.isFinite(seconds) && seconds >= 1 && seconds <= 8 * 3600) log(req.user._id, 'session', { seconds });
  res.status(204).end();
}));

module.exports = router;
