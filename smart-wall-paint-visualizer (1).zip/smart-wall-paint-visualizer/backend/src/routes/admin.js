const express = require('express');
const path = require('path');
const User = require('../models/User');
const Color = require('../models/Color');
const Pattern = require('../models/Pattern');
const Project = require('../models/Project');
const Activity = require('../models/Activity');
const Feedback = require('../models/Feedback');
const { protect, adminOnly } = require('../middleware/auth');
const { makeUpload, hasImageSignature, removeFile } = require('../middleware/upload');
const { getSettings, updateSettings } = require('../utils/settings');
const wrap = require('../utils/wrap');

const router = express.Router();
const patternUpload = makeUpload('patterns', 2 * 1024 * 1024);
router.use(protect, adminOnly);

const FINISHES = ['matte', 'satin', 'glossy', 'eggshell'];
const list = (v) => (Array.isArray(v) ? v : String(v || '').split(',')).map((s) => String(s).trim()).filter(Boolean);

function colorFields(b) {
  const out = {};
  if (b.name !== undefined) out.name = b.name;
  if (b.code !== undefined) out.code = b.code;
  if (b.hex !== undefined) out.hex = b.hex;
  if (b.brand !== undefined) out.brand = b.brand;
  if (b.swatch !== undefined) out.swatch = b.swatch;
  if (b.active !== undefined) out.active = Boolean(b.active);
  if (b.finishes !== undefined) out.finishes = list(b.finishes).filter((f) => FINISHES.includes(f));
  if (b.categories !== undefined) out.categories = list(b.categories).slice(0, 10);
  return out;
}

/* ---------- Colours ---------- */
router.get('/colors', wrap(async (req, res) => res.json(await Color.find().sort('name'))));
router.post('/colors', wrap(async (req, res) => res.status(201).json(await Color.create(colorFields(req.body)))));
router.put('/colors/:id', wrap(async (req, res) => {
  const color = await Color.findById(req.params.id);
  if (!color) return res.status(404).json({ message: 'Colour not found' });
  color.set(colorFields(req.body));
  await color.save();
  res.json(color);
}));
router.delete('/colors/:id', wrap(async (req, res) => {
  await Color.findByIdAndDelete(req.params.id);
  await User.updateMany({}, { $pull: { favouriteColors: req.params.id } });
  res.status(204).end();
}));

/* ---------- Patterns / designs ---------- */
router.get('/patterns', wrap(async (req, res) => res.json(await Pattern.find().sort('name'))));
router.post('/patterns', patternUpload.single('image'), wrap(async (req, res) => {
  const b = req.body;
  let imageUrl = String(b.imageUrl || '');
  if (req.file) {
    if (!hasImageSignature(req.file.path)) {
      removeFile(req.file.path);
      return res.status(400).json({ message: 'That file is not a valid JPG or PNG image' });
    }
    imageUrl = `/uploads/patterns/${req.file.filename}`;
  }
  if (!imageUrl) return res.status(400).json({ message: 'Upload a texture image' });
  const p = await Pattern.create({
    name: b.name, description: b.description, category: b.category, imageUrl,
    width: Number(b.width) || 80, height: Number(b.height) || 80, scale: Number(b.scale) || 1,
  });
  res.status(201).json(p);
}));
router.put('/patterns/:id', wrap(async (req, res) => {
  const p = await Pattern.findById(req.params.id);
  if (!p) return res.status(404).json({ message: 'Pattern not found' });
  ['name', 'description', 'category'].forEach((k) => { if (req.body[k] !== undefined) p[k] = req.body[k]; });
  if (req.body.scale !== undefined) p.scale = Number(req.body.scale) || 1;
  if (req.body.active !== undefined) p.active = Boolean(req.body.active);
  await p.save();
  res.json(p);
}));
router.delete('/patterns/:id', wrap(async (req, res) => {
  const p = await Pattern.findByIdAndDelete(req.params.id);
  if (p && p.imageUrl.startsWith('/uploads/patterns/')) removeFile(path.join(__dirname, '../../uploads/patterns', path.basename(p.imageUrl)));
  await User.updateMany({}, { $pull: { favouritePatterns: req.params.id } });
  res.status(204).end();
}));

/* ---------- Users ---------- */
router.get('/users', wrap(async (req, res) => {
  const [users, counts] = await Promise.all([
    User.find().sort('-createdAt'),
    Project.aggregate([{ $group: { _id: '$user', projects: { $sum: 1 }, saved: { $sum: { $cond: ['$saved', 1, 0] } } } }]),
  ]);
  const map = new Map(counts.map((c) => [String(c._id), c]));
  res.json(users.map((u) => ({ ...u.toJSON(), projectCount: (map.get(String(u._id)) || {}).projects || 0, savedCount: (map.get(String(u._id)) || {}).saved || 0 })));
}));
router.put('/users/:id', wrap(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ message: 'User not found' });
  const self = String(user._id) === String(req.user._id);
  if (req.body.role && ['user', 'admin'].includes(req.body.role)) {
    if (self && req.body.role !== 'admin') return res.status(400).json({ message: 'You cannot remove your own admin role' });
    user.role = req.body.role;
  }
  if (req.body.active !== undefined) {
    if (self && !req.body.active) return res.status(400).json({ message: 'You cannot deactivate yourself' });
    user.active = Boolean(req.body.active);
  }
  if (req.body.permissions !== undefined) user.permissions = list(req.body.permissions);
  await user.save();
  res.json(user);
}));
router.delete('/users/:id', wrap(async (req, res) => {
  if (String(req.params.id) === String(req.user._id)) return res.status(400).json({ message: 'You cannot delete yourself' });
  const projects = await Project.find({ user: req.params.id });
  projects.forEach((p) => p.originalImage && p.originalImage.filename && removeFile(path.join(__dirname, '../../uploads/rooms', path.basename(p.originalImage.filename))));
  await Project.deleteMany({ user: req.params.id });
  await User.findByIdAndDelete(req.params.id);
  res.status(204).end();
}));

/* ---------- Saved designs of all users ---------- */
router.get('/projects', wrap(async (req, res) => {
  res.json(await Project.find().select('-trials.walls').populate('user', 'name email').sort('-updatedAt').limit(200));
}));
router.delete('/projects/:id', wrap(async (req, res) => {
  const p = await Project.findByIdAndDelete(req.params.id);
  if (p) {
    p.originalImage && p.originalImage.filename && removeFile(path.join(__dirname, '../../uploads/rooms', path.basename(p.originalImage.filename)));
    await User.updateOne({ _id: p.user }, { $pull: { projects: p._id } });
  }
  res.status(204).end();
}));

/* ---------- Activity, feedback, settings ---------- */
router.get('/activity', wrap(async (req, res) => {
  res.json(await Activity.find({ action: { $ne: 'session' } }).sort('-createdAt').limit(100).populate('user', 'name email'));
}));
router.get('/feedback', wrap(async (req, res) => res.json(await Feedback.find().sort('-createdAt').limit(50).populate('user', 'name'))));
router.get('/settings', wrap(async (req, res) => res.json(await getSettings())));
router.put('/settings', wrap(async (req, res) => res.json(await updateSettings(req.body))));

/* ---------- KPI dashboard ---------- */
router.get('/stats', wrap(async (req, res) => {
  const since = new Date();
  since.setHours(0, 0, 0, 0);
  since.setDate(since.getDate() - 6);
  const [users, uploads, saved, downloads, session, rating, perDay, topColors] = await Promise.all([
    User.countDocuments(),
    Project.countDocuments(),
    Project.countDocuments({ saved: true }),
    Activity.countDocuments({ action: 'download' }),
    Activity.aggregate([{ $match: { action: 'session' } }, { $group: { _id: null, avg: { $avg: '$meta.seconds' }, n: { $sum: 1 } } }]),
    Feedback.aggregate([{ $group: { _id: null, avg: { $avg: '$rating' }, n: { $sum: 1 } } }]),
    Project.aggregate([
      { $match: { createdAt: { $gte: since } } },
      { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } }, n: { $sum: 1 } } },
    ]),
    Project.aggregate([
      { $unwind: '$trials' },
      { $unwind: '$trials.walls' },
      { $group: { _id: '$trials.walls.color', uses: { $sum: 1 } } },
      { $sort: { uses: -1 } },
      { $limit: 6 },
    ]),
  ]);
  const days = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(since);
    d.setDate(since.getDate() + i);
    const key = d.toISOString().slice(0, 10);
    const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    const hit = perDay.find((x) => x._id === key || x._id === local);
    days.push({ date: local, uploads: hit ? hit.n : 0 });
  }
  res.json({
    users,
    uploads,
    savedDesigns: saved,
    downloads,
    avgSessionSeconds: session[0] ? Math.round(session[0].avg) : 0,
    avgRating: rating[0] ? Number(rating[0].avg.toFixed(2)) : 0,
    feedbackCount: rating[0] ? rating[0].n : 0,
    uploadsPerDay: days,
    topColors: topColors.map((c) => ({ color: c._id, uses: c.uses })),
  });
}));

module.exports = router;
