const express = require('express');
const Color = require('../models/Color');
const Pattern = require('../models/Pattern');
const Feedback = require('../models/Feedback');
const { protect } = require('../middleware/auth');
const wrap = require('../utils/wrap');
const log = require('../utils/activity');
const { getSettings } = require('../utils/settings');

const router = express.Router();

// Public: site name, upload limit, accuracy disclaimer
router.get('/settings/public', wrap(async (req, res) => {
  const { siteName, maxUploadMB, allowRegistration, disclaimer } = await getSettings();
  res.json({ siteName, maxUploadMB, allowRegistration, disclaimer });
}));

router.get('/colors', protect, wrap(async (req, res) => {
  const q = { active: true };
  if (req.query.category) q.categories = String(req.query.category);
  if (req.query.brand) q.brand = String(req.query.brand);
  if (req.query.q) q.name = new RegExp(String(req.query.q).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
  res.json(await Color.find(q).sort('name'));
}));

router.get('/patterns', protect, wrap(async (req, res) => {
  const q = { active: true };
  if (req.query.category) q.category = String(req.query.category);
  res.json(await Pattern.find(q).sort('name'));
}));

router.post('/feedback', protect, wrap(async (req, res) => {
  const rating = Number(req.body.rating);
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) return res.status(400).json({ message: 'Rating must be 1 to 5' });
  const fb = await Feedback.create({ user: req.user._id, rating, comment: String(req.body.comment || '').slice(0, 500) });
  log(req.user._id, 'feedback', { rating });
  res.status(201).json(fb);
}));

module.exports = router;
