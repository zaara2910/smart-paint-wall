const express = require('express');
const path = require('path');
const Project = require('../models/Project');
const User = require('../models/User');
const { protect } = require('../middleware/auth');
const { makeUpload, hasImageSignature, removeFile } = require('../middleware/upload');
const { cleanTrials } = require('../utils/wall');
const { getSettings } = require('../utils/settings');
const wrap = require('../utils/wrap');
const log = require('../utils/activity');

const router = express.Router();
const upload = makeUpload('rooms', 20 * 1024 * 1024); // hard cap; the admin-configurable limit is checked below
router.use(protect);

const own = (req) => ({ _id: req.params.id, user: req.user._id });

router.get('/', wrap(async (req, res) => {
  const q = { user: req.user._id };
  if (req.query.saved === 'true') q.saved = true;
  res.json(await Project.find(q).select('-trials.walls').sort('-updatedAt'));
}));

// Upload a room photo (multipart/form-data: image, title, width, height)
router.post('/', upload.single('image'), wrap(async (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).json({ message: 'Choose a JPG or PNG image to upload' });
  const settings = await getSettings();
  if (file.size > settings.maxUploadMB * 1024 * 1024) {
    removeFile(file.path);
    return res.status(413).json({ message: `Image must be smaller than ${settings.maxUploadMB} MB` });
  }
  if (!hasImageSignature(file.path)) {
    removeFile(file.path);
    return res.status(400).json({ message: 'That file is not a valid JPG or PNG image' });
  }
  const project = await Project.create({
    user: req.user._id,
    title: String(req.body.title || '').trim().slice(0, 80) || path.parse(file.originalname).name.slice(0, 80) || 'Untitled room',
    originalImage: {
      url: `/uploads/rooms/${file.filename}`,
      filename: file.filename,
      mimeType: file.mimetype,
      size: file.size,
      width: Number(req.body.width) || undefined,
      height: Number(req.body.height) || undefined,
    },
  });
  await User.updateOne({ _id: req.user._id }, { $push: { projects: project._id } });
  log(req.user._id, 'upload', { project: project._id });
  res.status(201).json(project);
}));

router.get('/:id', wrap(async (req, res) => {
  const project = await Project.findOne(own(req));
  if (!project) return res.status(404).json({ message: 'Project not found' });
  res.json(project);
}));

// Save title, trials (wall selections + paint settings), thumbnail
router.put('/:id', wrap(async (req, res) => {
  const project = await Project.findOne(own(req));
  if (!project) return res.status(404).json({ message: 'Project not found' });
  const settings = await getSettings();
  const { title, trials, activeTrial, thumbnail, saved } = req.body;
  if (typeof title === 'string' && title.trim()) project.title = title.trim().slice(0, 80);
  if (trials !== undefined) {
    const cleaned = cleanTrials(trials, settings.maxTrialsPerProject);
    if (!cleaned) return res.status(400).json({ message: 'At least one design trial is required' });
    project.trials = cleaned;
    project.markModified('trials');
  }
  if (Number.isInteger(activeTrial)) project.activeTrial = Math.max(0, Math.min(activeTrial, project.trials.length - 1));
  if (typeof thumbnail === 'string') {
    if (thumbnail && !/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(thumbnail)) return res.status(400).json({ message: 'Invalid thumbnail' });
    if (thumbnail.length > 600000) return res.status(400).json({ message: 'Thumbnail is too large' });
    project.thumbnail = thumbnail;
  }
  if (typeof saved === 'boolean') project.saved = saved;
  await project.save();
  if (saved) log(req.user._id, 'save', { project: project._id, trials: project.trials.length });
  res.json(project);
}));

router.post('/:id/downloaded', wrap(async (req, res) => {
  const project = await Project.findOne(own(req));
  if (!project) return res.status(404).json({ message: 'Project not found' });
  log(req.user._id, 'download', { project: project._id });
  res.status(204).end();
}));

router.delete('/:id', wrap(async (req, res) => {
  const project = await Project.findOneAndDelete(own(req));
  if (!project) return res.status(404).json({ message: 'Project not found' });
  if (project.originalImage && project.originalImage.filename) {
    removeFile(path.join(__dirname, '../../uploads/rooms', path.basename(project.originalImage.filename)));
  }
  await User.updateOne({ _id: req.user._id }, { $pull: { projects: project._id } });
  log(req.user._id, 'delete', { project: project._id });
  res.status(204).end();
}));

module.exports = router;
