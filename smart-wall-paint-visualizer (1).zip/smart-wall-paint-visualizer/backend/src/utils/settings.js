const Setting = require('../models/Setting');

const DEFAULTS = {
  siteName: 'Smart Wall Paint Visualizer',
  maxUploadMB: 8,
  allowRegistration: true,
  maxTrialsPerProject: 10,
  disclaimer:
    'Colours shown are a digital approximation. Final results may vary due to lighting, screen calibration and wall texture.',
};

async function getSettings() {
  const rows = await Setting.find();
  const s = { ...DEFAULTS };
  rows.forEach((r) => {
    if (r.key in DEFAULTS) s[r.key] = r.value;
  });
  return s;
}

async function updateSettings(input) {
  for (const key of Object.keys(DEFAULTS)) {
    if (!(key in input)) continue;
    let v = input[key];
    if (typeof DEFAULTS[key] === 'number') {
      v = Number(v);
      if (!Number.isFinite(v) || v < 1 || v > 50) continue;
    } else if (typeof DEFAULTS[key] === 'boolean') {
      v = Boolean(v);
    } else {
      v = String(v).trim().slice(0, 400);
      if (!v) continue;
    }
    await Setting.findOneAndUpdate({ key }, { key, value: v }, { upsert: true, new: true });
  }
  return getSettings();
}

module.exports = { getSettings, updateSettings, DEFAULTS };
