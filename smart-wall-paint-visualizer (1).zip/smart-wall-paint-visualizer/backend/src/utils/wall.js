// Whitelists and clamps wall data coming from the browser before it is stored.
const num = (v, min, max, d) => {
  v = Number(v);
  return Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : d;
};
const hex = (v) => (typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v) ? v.toLowerCase() : null);
const str = (v, n, d = null) => (v ? String(v).slice(0, n) : d);
const pts = (arr, max) =>
  Array.isArray(arr)
    ? arr
        .slice(0, max)
        .filter((p) => Array.isArray(p) && p.length >= 2)
        .map((p) => [num(p[0], 0, 1, 0), num(p[1], 0, 1, 0)])
    : [];

function cleanWall(w, i) {
  if (!w || typeof w !== 'object') return null;
  const kind = w.kind === 'brush' ? 'brush' : 'polygon';
  const out = {
    id: str(w.id, 40, 'w' + i),
    name: str(w.name, 40, `Wall ${i + 1}`),
    kind,
    points: [],
    strokes: [],
    size: num(w.size, 0.001, 0.2, 0.02),
    mode: ['solid', 'dual', 'pattern'].includes(w.mode) ? w.mode : 'solid',
    color: hex(w.color) || '#ffffff',
    colorId: str(w.colorId, 40),
    color2: hex(w.color2) || '#ffffff',
    color2Id: str(w.color2Id, 40),
    splitRatio: num(w.splitRatio, 0.05, 0.95, 0.5),
    patternId: str(w.patternId, 40),
    patternScale: num(w.patternScale, 0.2, 4, 1),
    finish: ['matte', 'satin', 'glossy', 'eggshell'].includes(w.finish) ? w.finish : 'matte',
    opacity: num(w.opacity, 0.05, 1, 0.85),
    brightness: num(w.brightness, -50, 50, 0),
    blend: w.blend === 'color' ? 'color' : 'multiply',
  };
  if (kind === 'polygon') {
    out.points = pts(w.points, 500);
    if (out.points.length < 3) return null;
  } else {
    out.strokes = Array.isArray(w.strokes) ? w.strokes.slice(0, 200).map((s) => pts(s, 2000)).filter((s) => s.length) : [];
    if (!out.strokes.length) return null;
  }
  return out;
}

function cleanTrials(trials, maxTrials) {
  if (!Array.isArray(trials) || !trials.length) return null;
  return trials.slice(0, maxTrials).map((t, ti) => ({
    name: str(t && t.name, 40, `Trial ${ti + 1}`),
    walls: (Array.isArray(t && t.walls) ? t.walls.slice(0, 100) : []).map(cleanWall).filter(Boolean),
    updatedAt: new Date(),
  }));
}

module.exports = { cleanWall, cleanTrials };
