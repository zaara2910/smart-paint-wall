const Activity = require('../models/Activity');

// Fire-and-forget activity logging; never breaks the request
module.exports = function logActivity(user, action, meta = {}) {
  return Activity.create({ user, action, meta }).catch(() => {});
};
