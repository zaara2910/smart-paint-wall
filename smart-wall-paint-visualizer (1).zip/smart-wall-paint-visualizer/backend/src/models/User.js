const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, minlength: 2, maxlength: 60 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },
    role: { type: String, enum: ['user', 'admin'], default: 'user' },
    // Admin privileges, e.g. manage_colors, manage_patterns, manage_users, view_activity, manage_settings
    permissions: { type: [String], default: [] },
    projects: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Project' }],
    favouriteColors: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Color' }],
    favouritePatterns: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Pattern' }],
    active: { type: Boolean, default: true },
    lastLoginAt: Date,
  },
  { timestamps: true }
);

userSchema.set('toJSON', {
  transform: (doc, ret) => {
    delete ret.passwordHash;
    delete ret.__v;
    return ret;
  },
});

module.exports = mongoose.model('User', userSchema);
