const mongoose = require('mongoose');

const colorSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 60 },
    code: { type: String, trim: true, maxlength: 30 }, // shade code, e.g. "SW-1021"
    hex: { type: String, required: true, match: [/^#[0-9a-fA-F]{6}$/, 'HEX must look like #aabbcc'], lowercase: true },
    rgb: { r: Number, g: Number, b: Number },
    brand: { type: String, trim: true, maxlength: 60, default: 'Generic' },
    finishes: { type: [String], enum: ['matte', 'satin', 'glossy', 'eggshell'], default: ['matte', 'satin', 'glossy'] },
    categories: { type: [String], default: [] }, // e.g. "Living Room", "Accent"
    swatch: { type: String, default: '' }, // optional swatch image URL; falls back to the HEX colour
    active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

colorSchema.pre('save', function (next) {
  const n = parseInt(this.hex.slice(1), 16);
  this.rgb = { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  next();
});

module.exports = mongoose.model('Color', colorSchema);
