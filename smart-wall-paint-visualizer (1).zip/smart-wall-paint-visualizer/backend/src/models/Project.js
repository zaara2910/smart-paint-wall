const mongoose = require('mongoose');

// A design trial = one set of painted walls. A project (room photo) can hold several trials.
const trialSchema = new mongoose.Schema(
  {
    name: { type: String, default: 'Trial 1' },
    walls: { type: [mongoose.Schema.Types.Mixed], default: [] }, // wall selection polygons/strokes + applied colour/design settings (JSON)
    updatedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

const projectSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, trim: true, maxlength: 80, default: 'Untitled room' },
    originalImage: {
      url: { type: String, required: true },
      filename: String,
      mimeType: String,
      size: Number,
      width: Number,
      height: Number,
    },
    trials: { type: [trialSchema], default: () => [{ name: 'Trial 1', walls: [] }] },
    activeTrial: { type: Number, default: 0 },
    thumbnail: { type: String, default: '' }, // small JPEG data URI of the painted result
    saved: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Project', projectSchema);
