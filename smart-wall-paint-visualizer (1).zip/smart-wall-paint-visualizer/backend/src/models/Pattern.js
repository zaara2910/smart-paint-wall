const mongoose = require('mongoose');

const patternSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 60 },
    description: { type: String, trim: true, maxlength: 300, default: '' },
    category: { type: String, trim: true, maxlength: 40, default: 'General' }, // Floral, Geometric ...
    imageUrl: { type: String, required: true }, // texture / sample (URL or data URI)
    width: { type: Number, default: 80 },
    height: { type: Number, default: 80 },
    scale: { type: Number, default: 1, min: 0.2, max: 4 }, // default scaling
    active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Pattern', patternSchema);
