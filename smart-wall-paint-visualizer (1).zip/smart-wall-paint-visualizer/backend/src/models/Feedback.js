const mongoose = require('mongoose');

module.exports = mongoose.model(
  'Feedback',
  new mongoose.Schema(
    {
      user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
      rating: { type: Number, min: 1, max: 5, required: true },
      comment: { type: String, trim: true, maxlength: 500, default: '' },
    },
    { timestamps: { createdAt: true, updatedAt: false } }
  )
);
