const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const TYPES = { 'image/jpeg': '.jpg', 'image/png': '.png' };

// Creates a multer instance that only accepts JPG/PNG and stores files under uploads/<dir>
function makeUpload(dir, maxBytes) {
  const folder = path.join(__dirname, '../../uploads', dir);
  fs.mkdirSync(folder, { recursive: true });
  return multer({
    storage: multer.diskStorage({
      destination: folder,
      filename: (req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex') + TYPES[file.mimetype]),
    }),
    limits: { fileSize: maxBytes, files: 1 },
    fileFilter: (req, file, cb) => {
      if (TYPES[file.mimetype]) return cb(null, true);
      const err = new Error('Only JPG and PNG images are allowed');
      err.status = 400;
      cb(err);
    },
  });
}

// Confirms the file content really is a PNG/JPEG (not just a renamed file)
function hasImageSignature(filePath) {
  const fd = fs.openSync(filePath, 'r');
  const buf = Buffer.alloc(8);
  fs.readSync(fd, buf, 0, 8, 0);
  fs.closeSync(fd);
  const png = buf.slice(0, 4).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47]));
  const jpg = buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  return png || jpg;
}

const removeFile = (filePath) => fs.unlink(filePath, () => {});

module.exports = { makeUpload, hasImageSignature, removeFile };
