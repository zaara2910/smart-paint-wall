# REST API

Base URL: `/api`. All routes except register, login, health and `settings/public` need `Authorization: Bearer <token>`. Errors return `{ "message": "..." }`.

## Auth
| Method | Path | Body | Notes |
|---|---|---|---|
| POST | /auth/register | name, email, password | Password 8+ chars with a letter and a number. Returns `{ token, user }` |
| POST | /auth/login | email, password | Returns `{ token, user }` |
| GET | /auth/me | | Current user |
| PUT | /auth/me | name?, currentPassword?, newPassword? | Update profile or password |
| PUT | /auth/favourites | type (`color`\|`pattern`), id | Toggles a favourite |
| POST | /auth/session | seconds | Records session time for the KPI |

## Catalogue
| Method | Path | Notes |
|---|---|---|
| GET | /settings/public | Public: site name, upload limit, disclaimer |
| GET | /colors?category=&brand=&q= | Active colours |
| GET | /patterns?category= | Active patterns |
| POST | /feedback | rating (1-5), comment |

## Projects (room photos and designs)
| Method | Path | Notes |
|---|---|---|
| GET | /projects?saved=true | Own projects (without wall data) |
| POST | /projects | multipart: `image` (JPG/PNG), title, width, height |
| GET | /projects/:id | Full project with trials and walls |
| PUT | /projects/:id | title, trials, activeTrial, thumbnail (JPEG data URI), saved |
| POST | /projects/:id/downloaded | Logs a download |
| DELETE | /projects/:id | Removes project and photo |

## Admin (role: admin)
| Method | Path |
|---|---|
| GET/POST | /admin/colors |
| PUT/DELETE | /admin/colors/:id |
| GET/POST | /admin/patterns (POST is multipart with `image`) |
| PUT/DELETE | /admin/patterns/:id |
| GET | /admin/users |
| PUT/DELETE | /admin/users/:id (role, active, permissions) |
| GET | /admin/projects, DELETE /admin/projects/:id |
| GET | /admin/activity, GET /admin/feedback |
| GET/PUT | /admin/settings |
| GET | /admin/stats (KPIs) |
