# MongoDB collections

**users**: name, email (unique), passwordHash, role (`user`|`admin`), permissions[], projects[] (refs), favouriteColors[], favouritePatterns[], active, lastLoginAt, createdAt. Admins use the same schema.

**projects**: user (ref), title, originalImage {url, filename, mimeType, size, width, height}, trials[] {name, walls[], updatedAt}, activeTrial, thumbnail, saved, createdAt, updatedAt.

A wall (JSON, coordinates normalised 0-1):
```json
{ "id": "w1", "name": "Wall 1", "kind": "polygon", "points": [[0.1,0.2],[0.6,0.2],[0.6,0.8]],
  "strokes": [], "size": 0.02, "mode": "dual", "color": "#7fb7d6", "colorId": "...",
  "color2": "#f4f1ea", "color2Id": "...", "splitRatio": 0.5, "patternId": null, "patternScale": 1,
  "finish": "matte", "opacity": 0.85, "brightness": 0, "blend": "multiply" }
```

**colors**: name, code, hex, rgb {r,g,b}, brand, finishes[], categories[], swatch, active.

**patterns**: name, description, category, imageUrl (URL or data URI), width, height, scale, active.

**activities**: user, action (register, login, upload, save, download, delete, feedback, session), meta, createdAt.

**feedbacks**: user, rating (1-5), comment, createdAt.

**settings**: key, value (siteName, maxUploadMB, allowRegistration, maxTrialsPerProject, disclaimer).
