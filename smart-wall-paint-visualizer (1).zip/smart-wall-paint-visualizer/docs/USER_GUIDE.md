# User guide

1. **Register or log in.** Use the demo account `demo@paintvisualizer.com` / `Demo@12345` to try it out.
2. **Upload a room photo** (JPG or PNG that you own). Clear, well-lit photos give the best results.
3. **Select walls.**
   - Polygon: click each corner; double-click, press Enter, or click the first point to finish.
   - Brush: drag over the area; strokes add to the selected brush wall.
   - Edit: click a wall, drag its corner points; right-click (or Alt+click) a point to remove it.
4. **Paint.** Choose Solid, Dual-tone (pick the Lower and Upper colours, set the split height) or Pattern. Adjust opacity, brightness, finish and blend. Use the heart to favourite colours and patterns.
5. **Compare.** Before, After and Split (drag the divider).
6. **Try alternatives** with design trials (New trial, Duplicate, Rename, Delete).
7. **Save design** to find it later in Saved designs, or **Download** a PNG of the painted room or a before/after image.

Shortcuts: Enter finish polygon, Esc cancel, Ctrl+Z undo, Ctrl+Y redo, Delete remove selected wall.

Colours on screen are an approximation. Lighting, screen calibration and wall texture change the final result, so test a small patch first.
