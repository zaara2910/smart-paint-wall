# Smart Wall Paint Visualizer

A web-based, MEAN-stack application that lets users upload a photo of their own room, select the walls manually, and preview paint colours, dual-tone walls and patterns before they paint. Includes before/after comparison, multiple design trials per photo, save and download, user and admin roles, and a live KPI dashboard.

| Layer | Technology |
|-------|-----------|
| Frontend | Angular 18 (standalone components), TypeScript, HTML5 Canvas, SCSS |
| Backend | Node.js, Express, RESTful APIs, JWT authentication |
| Database | MongoDB (Mongoose) |

## Project structure

```
smart-wall-paint-visualizer/
├── backend/                 Node + Express API
│   ├── server.js
│   ├── .env.example
│   ├── uploads/             room photos and pattern textures (git-ignored)
│   └── src/
│       ├── models/          User, Project, Color, Pattern, Activity, Feedback, Setting
│       ├── routes/          auth, projects, catalog (colours/patterns/feedback), admin
│       ├── middleware/      auth (JWT + roles), upload (JPG/PNG validation), sanitize, error
│       ├── utils/           settings, activity log, wall-data sanitizer
│       └── seed.js          admin + demo user + 28 colours + 6 patterns
├── frontend/                Angular app
│   └── src/app/
│       ├── core/            models, auth service, JWT interceptor, route guards
│       └── pages/           auth (login/register), home, upload, editor, saved,
│                            favourites, help, admin
└── docs/                    API.md, DATABASE.md, USER_GUIDE.md
```

## Run it in VS Code

**Prerequisites:** Node.js 18.19+ (20 LTS recommended), and MongoDB running locally (or a free MongoDB Atlas connection string).

1. Open the `smart-wall-paint-visualizer` folder in VS Code (**File > Open Folder**).
2. Open two terminals (**Terminal > New Terminal**, then use the split button).

**Terminal 1: backend**
```bash
cd backend
npm install
cp .env.example .env      # on Windows: copy .env.example .env  (a ready .env is already included)
# edit .env: set a strong JWT_SECRET and, for Atlas, your MONGO_URI
npm run seed              # creates admin, demo user, colours and patterns
npm run dev               # API on http://localhost:5000
```

**Terminal 2: frontend**
```bash
cd frontend
npm install
npm start                 # app on http://localhost:4200 (proxies /api and /uploads to :5000)
```

Open http://localhost:4200.

| Account | Email | Password |
|---------|-------|----------|
| Admin | admin@paintvisualizer.com | Admin@12345 |
| Demo user | demo@paintvisualizer.com | Demo@12345 |

Change the admin password and `JWT_SECRET` before deploying anywhere public.

## Features (mapped to the PRD)

**User**
- Registration and login with JWT; roles: User and Admin
- Upload room images (JPG/PNG), validated by type, size and file signature
- Manual wall selection with **polygon** and **brush** tools; select tool to drag corner points, delete points, rename and remove walls (editable selection)
- Solid colours, **dual-tone** walls (adjustable split height) and **patterns**
- Opacity, brightness, finish (matte, satin, glossy, eggshell) and blend (Realistic or Vivid) controls
- **Before / After / Split** preview with a draggable divider
- **Multiple design trials** per image (add, duplicate, rename, delete)
- Undo/redo, keyboard shortcuts, custom colour picker
- Favourite colours and patterns
- Save designs, reopen later, download the painted room or a before/after image (PNG)
- In-app "How to use" guide and feedback form
- Accuracy disclaimer about lighting, screen calibration and wall texture

**Admin**
- Colour management: name, shade code, HEX/RGB, brand, finishes, category tags, show/hide
- Add, hide or remove patterns (upload your own texture image)
- View all users (activate, deactivate, change role, delete), user activity log and every saved design
- System configuration: upload limit, trial limit, registration on/off, disclaimer text
- **Analytics dashboard** (auto-refreshing every 10 s): images uploaded, designs saved, average session duration, satisfaction rating, downloads, uploads per day, most-used colours, latest feedback

**Security and quality**
- bcrypt password hashing, JWT auth, role checks on every admin route
- Helmet, CORS allow-list, rate limiting (stricter on auth), NoSQL-operator sanitising
- Image uploads: MIME filter, size limit, magic-byte check, random file names
- All wall/trial data is whitelisted and range-checked server-side before it is stored
- Clean modular architecture; lazy-loaded Angular pages (9 interconnected pages)

## Pages

Login, Register, Home, Upload, Editor (wall selection + colour preview), Saved designs, Favourites, Help (guide + feedback), Admin panel (7 tabs).

## How the paint preview works

The photo is drawn on an HTML5 canvas. Each wall is stored as normalised polygon or brush-stroke coordinates, so it works at any image size. For each wall the app builds a colour layer (solid, dual-tone or pattern), applies brightness and finish, masks it to the wall shape, then blends it onto the photo with the canvas `multiply` mode (or `color` for a more vivid look). Because the photo's own light and shadow are kept, the result looks like paint on the real wall. It works best on light or mid-tone walls.

## Deployment

**Option A: single server (simplest, e.g. AWS EC2, Render, Railway)**
```bash
cd frontend && npm install && npm run build     # creates frontend/dist/frontend/browser
cd ../backend && npm install --omit=dev
# set NODE_ENV=production, MONGO_URI (Atlas), JWT_SECRET, CLIENT_ORIGIN in the environment
npm run seed && npm start
```
The Express server automatically serves the built Angular app and the API from one domain. Put it behind HTTPS (Nginx, Caddy, or the platform's TLS) and point your domain at it.

**Option B: split hosting (Vercel or Netlify for the frontend, any Node host for the API)**
1. Deploy `backend/` to a Node host (Render, Railway, AWS Elastic Beanstalk) and set `CLIENT_ORIGIN` to your frontend URL.
2. Deploy `frontend/` to Vercel/Netlify. Edit `frontend/vercel.json` and replace `YOUR-BACKEND-URL` (for Netlify, create `_redirects` with `/api/* https://YOUR-BACKEND-URL/api/:splat 200` and the same for `/uploads/*`). Build command `npm run build`, output directory `dist/frontend/browser`.

Uploaded photos are stored on the server disk (`backend/uploads`). On hosts with ephemeral disks, attach a persistent volume or move storage to S3 (the DB only stores the file URL, so this is a contained change in `middleware/upload.js`).

## Troubleshooting

- **"Database connection failed"**: start MongoDB (`mongod`) or use an Atlas URI in `.env`.
- **Login page says it cannot reach the server**: make sure the backend is running on port 5000 and the frontend was started with `npm start` (it uses the proxy file).
- **Photo does not load in the editor**: the API and `/uploads` must be reachable from the same origin as the app (proxy in development, rewrites or single-server deploy in production).
- **Wall looks too dark or too light**: raise opacity, adjust brightness, or switch Blend to Vivid.
